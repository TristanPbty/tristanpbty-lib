# Tristan's Lib (`tristanpbty_lib`)

The shared foundation of TristanPbty's native Horizon mods: the configuration
system, the UI widgets and the Minecraft tool abstractions — a **library
mod**, shipped as the source-only `tristanpbty_lib-1.1.0.hnmod` that the
Horizon launcher compiles into the game.

A Horizon native mod is a source mixin bundle (horizon-mixins): this
repository's `mixins/tristanpbty_lib/` holds the bundle — the manifest plus
the library crate, staged into the game build as its own workspace member
(a `[[crate]]` that `horizon-client` depends on). The library is pure Rust
on `std` alone, with **zero dependencies** (a bundle crate may only use
registry crates already present in the game's `Cargo.lock`), so it stays
portable and testable outside the game.

## Layout

```
src/config/      schema, typed values, validation, migrations, atomic
                 persistence (.bak behind a Disk trait), debounced runtime
src/widgets/     the vanilla-style cycling button the config screens are
                 built from, plus button, toggle, slider, dropdown, number
                 input, color picker, keybind, position editor, scale
                 selector — abstract draw commands and input events, so the
                 same code runs in unit tests and against the game
src/minecraft/   equipment snapshots, durability math, warning thresholds
src/utils/       colors, geometry, the anchor vocabulary
mixins/tristanpbty_lib/   the bundle: horizon-mixin.toml + the lib/ crate
                 copy that ships in the .hnmod (tools/sync_bundle.py keeps
                 it identical to src/)
tests/           integration tests (config file round trips)
tools/           sync_bundle.py, package.py
```

## Build, test, package

```sh
cargo fmt --check && cargo clippy --all-targets --locked -- -D warnings
cargo test --locked                     # 73 tests
python3 tools/package.py                # → target/tristanpbty_lib-1.1.0.hnmod
```

The packager writes `horizon-native.json` plus every `.rs`/`.toml` of the
bundle and `LICENSES.md`, with fixed timestamps and modes, so the same
sources always give the same bytes and the same SHA-256. After editing
`src/`, re-run `tools/sync_bundle.py` (or `package.py`, which does it)
before packaging.

## Pins (compatibility.json)

| What | Pin |
|---|---|
| Horizon | Nightly **2026-11-08**, commit `fdc87aecdbd116bf1e08adcd062fcbaea8c2e2ca` |
| horizon-mixins | `d9c83d7096b7ea5b83678da2efdfd6161f74997e` (0.6.0, plan schema 6) |
| Rust | 1.95.0 (`rust-toolchain.toml`) |

The bundle touches no Horizon source: it only stages its crate into the
build, hence the empty `source_sha256`.

## Use in a mod

Install this `.hnmod` and the launcher stages the crate; a mod's injected
module then reaches it as `tristanpbty_lib::…`. TristanPbty's Armor Hud
1.1.0 embeds its own copy under its own crate name
(`tristanpbty_armor_hud_lib`) and no longer requires this mod beside it —
the two crates' names differ, so both mods install side by side without
conflict. This library remains the shared foundation for TristanPbty's
future native mods.

## Licenses

MIT, by TristanPbty — see `LICENSES.md` (which also travels inside the
`.hnmod`) for the full attributions: horizon-native-mod-template (MIT) for
the packaging approach, and the ideas-only debt to uku3lig's ukulib
(MPL-2.0). No Horizon source, no Minecraft assets.

## Changelog

- **1.1.0** — the `CycleButton` widget (the plain vanilla-style option
  button the configuration screens are built from: `Label: Value`, one
  click or scroll per step, wrapping options, striding numbers), the text
  color helpers behind the Armor Hud's *Text color* setting, and the
  debounced-autosave and `.bak` hardening of the persistence layer.
- **1.0.0** — proper name (Tristan's Lib), its own `.hnmod`, pinned to the
  newest Nightly (2026-11-08); `native_on` gating support for the mods that
  use it.
- **0.1.0** — initial release.
