//! The position editor: a miniature screen with the anchors marked on it,
//! where dragging the widget sets the `offsetX`/`offsetY` entries of the
//! configured anchor and side.
//!
//! The editor edits one position entry pair (stored as a `Position` value)
//! together with the `anchor` and `side` enum entries that decide where the
//! offsets apply; the miniature is drawn at `preview` scale, mirroring the
//! real screen's proportions.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT_DIM, Widget, draw_border,
    draw_label,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::ConfigValue;
use crate::utils::{Anchor, Rect, Side};

pub struct PositionEditor {
    /// The position entry (`offsetX`, `offsetY` as one `Position` value).
    key: String,
    /// The enum entries the geometry follows.
    anchor_key: String,
    side_key: String,
    rect: Rect,
    dragging: bool,
}

/// The miniature's inner padding.
const PAD: f32 = 8.0;

impl PositionEditor {
    pub fn new(key: &str, anchor_key: &str, side_key: &str, rect: Rect) -> PositionEditor {
        PositionEditor {
            key: key.to_string(),
            anchor_key: anchor_key.to_string(),
            side_key: side_key.to_string(),
            rect,
            dragging: false,
        }
    }

    fn anchor(&self, runtime: &ConfigRuntime) -> Anchor {
        Anchor::from_name(runtime.text(&self.anchor_key)).unwrap_or(Anchor::Hotbar)
    }

    fn side(&self, runtime: &ConfigRuntime) -> Side {
        Side::from_name(runtime.text(&self.side_key)).unwrap_or(Side::Left)
    }

    /// Where the miniature's widget sits for the current settings, in editor
    /// coordinates. The widget itself is drawn as a small strip of slots.
    ///
    /// Offsets follow the reference vocabulary: a positive X moves away from
    /// the anchor (left on the left side, right on the right), and a positive
    /// Y moves down from the top anchors and up from the bottom ones.
    fn widget_rect(&self, runtime: &ConfigRuntime, screen: Rect) -> Rect {
        let anchor = self.anchor(runtime);
        let side = self.side(runtime);
        let (ox, oy) = runtime.position(&self.key);
        let (w, h) = (Self::W, Self::H);
        let x = match anchor {
            Anchor::TopCenter => screen.x + (screen.w - w) / 2.0 + ox as f32,
            Anchor::Top | Anchor::Center | Anchor::Bottom => {
                if side == Side::Left {
                    screen.x - ox as f32
                } else {
                    screen.right() - w - ox as f32
                }
            }
            Anchor::Hotbar => {
                // The miniature hotbar mark is 44 wide, centered; the widget
                // sits just outside it, moving away with a positive offset.
                let center = screen.x + screen.w / 2.0;
                if side == Side::Left {
                    center - Self::HOTBAR_HALF - Self::GAP - w - ox as f32
                } else {
                    center + Self::HOTBAR_HALF + Self::GAP + ox as f32
                }
            }
        };
        let y = match anchor {
            Anchor::Top | Anchor::TopCenter => screen.y + PAD + oy as f32,
            Anchor::Center => screen.y + (screen.h - h) / 2.0 + oy as f32,
            Anchor::Bottom | Anchor::Hotbar => screen.bottom() - PAD - h - 18.0 - oy as f32,
        };
        Rect::new(x, y, w, h)
    }

    /// The widget strip's size in editor pixels.
    const W: f32 = 44.0;
    const H: f32 = 12.0;
    /// Half the miniature hotbar mark, and the gap beside it.
    const HOTBAR_HALF: f32 = 22.0;
    const GAP: f32 = 2.0;

    /// The widget's anchor point at offset zero, against which drags measure.
    fn base_point(&self, runtime: &ConfigRuntime, screen: Rect) -> (f32, f32) {
        let anchor = self.anchor(runtime);
        let side = self.side(runtime);
        let center = screen.x + screen.w / 2.0;
        let x = match anchor {
            Anchor::TopCenter => center - Self::W / 2.0,
            Anchor::Top | Anchor::Center | Anchor::Bottom => {
                if side == Side::Left {
                    screen.x
                } else {
                    screen.right() - Self::W
                }
            }
            Anchor::Hotbar => {
                if side == Side::Left {
                    center - Self::HOTBAR_HALF - Self::GAP - Self::W
                } else {
                    center + Self::HOTBAR_HALF + Self::GAP
                }
            }
        };
        let y = match anchor {
            Anchor::Top | Anchor::TopCenter => screen.y + PAD,
            Anchor::Center => screen.y + (screen.h - Self::H) / 2.0,
            Anchor::Bottom | Anchor::Hotbar => screen.bottom() - PAD - Self::H - 18.0,
        };
        (x, y)
    }

    fn screen_rect(&self) -> Rect {
        Rect::new(
            self.rect.x + PAD,
            self.rect.y + PAD,
            self.rect.w - PAD * 2.0,
            self.rect.h - PAD * 2.0,
        )
    }
}

impl Widget for PositionEditor {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if focused { PANEL_HOVER } else { PANEL },
        });
        draw_border(out, self.rect, super::BORDER);
        let screen = self.screen_rect();
        out.push(DrawCmd::Fill {
            rect: [screen.x, screen.y, screen.w, screen.h],
            argb: 0xFF2A_2A3A,
        });
        draw_border(out, screen, 0xFF3A_3A4A);
        // The hotbar mark along the bottom.
        let center = screen.x + screen.w / 2.0;
        out.push(DrawCmd::Fill {
            rect: [center - 22.0, screen.bottom() - 14.0, 44.0, 10.0],
            argb: 0xFF40_4040,
        });
        draw_border(
            out,
            Rect::new(center - 22.0, screen.bottom() - 14.0, 44.0, 10.0),
            super::BORDER,
        );
        // Anchor marks.
        let anchor = self.anchor(runtime);
        let (ax, ay) = match anchor {
            Anchor::TopCenter => (center, screen.y + 2.0),
            Anchor::Top => (screen.x + 2.0, screen.y + 2.0),
            Anchor::Center => (screen.x + 2.0, screen.y + screen.h / 2.0),
            Anchor::Bottom => (screen.x + 2.0, screen.bottom() - 2.0),
            Anchor::Hotbar => (center, screen.bottom() - 9.0),
        };
        out.push(DrawCmd::Fill {
            rect: [ax - 1.0, ay - 1.0, 2.0, 2.0],
            argb: ACCENT,
        });
        // The widget strip.
        let widget = self.widget_rect(runtime, screen);
        out.push(DrawCmd::Fill {
            rect: [widget.x, widget.y, widget.w, widget.h],
            argb: 0x8030_7C30,
        });
        draw_border(out, widget, ACCENT);
        for i in 0..4 {
            out.push(DrawCmd::Fill {
                rect: [widget.x + 2.0 + i as f32 * 10.0, widget.y + 2.0, 8.0, 8.0],
                argb: 0x60FF_FFFF,
            });
        }
        let (ox, oy) = runtime.position(&self.key);
        draw_label(
            out,
            &format!("offset {ox}, {oy}"),
            [self.rect.x + PAD, self.rect.bottom() - 10.0],
            TEXT_DIM,
        );
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        let screen = self.screen_rect();
        match event {
            InputEvent::Press { pos, button: 0 } => {
                let widget = self.widget_rect(runtime, screen);
                if widget.inflate(4.0).contains(*pos) {
                    self.dragging = true;
                    InputResult::consumed()
                } else {
                    InputResult::ignored()
                }
            }
            InputEvent::Drag { pos, button: 0, .. } if self.dragging => {
                // The offset is the distance from the anchor point, clamped
                // to sane bounds.
                let anchor = self.anchor(runtime);
                let side = self.side(runtime);
                let (ox, oy) = runtime.position(&self.key);
                // The grab point stays under the pointer: the widget's
                // center follows the cursor.
                let new_x = pos[0] - Self::W / 2.0;
                let new_y = pos[1] - Self::H / 2.0;
                let (base_x, base_y) = self.base_point(runtime, screen);
                let nx = match anchor {
                    Anchor::TopCenter => new_x - base_x,
                    // Both side anchors measure away from their edge, and the
                    // hotbar's right side grows the other way.
                    Anchor::Top | Anchor::Center | Anchor::Bottom | Anchor::Hotbar => {
                        if side == Side::Left {
                            base_x - new_x
                        } else {
                            new_x - base_x
                        }
                    }
                };
                let ny = match anchor {
                    Anchor::Top | Anchor::TopCenter | Anchor::Center => new_y - base_y,
                    Anchor::Bottom | Anchor::Hotbar => base_y - new_y,
                };
                let _ = (ox, oy);
                let clamped = (
                    nx.clamp(-100.0, 100.0) as i32,
                    ny.clamp(-100.0, 100.0) as i32,
                );
                InputResult::changed_if(
                    runtime.set(&self.key, ConfigValue::Position(clamped.0, clamped.1)),
                )
            }
            InputEvent::Release { button: 0, .. } if self.dragging => {
                self.dragging = false;
                InputResult::consumed()
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[
        ConfigEntry::position("offset", "Offset", "help", 0, 0),
        ConfigEntry::enumeration(
            "anchor",
            "Anchor",
            "help",
            &["HOTBAR", "TOP", "CENTER", "BOTTOM", "TOP_CENTER"],
            "HOTBAR",
        ),
        ConfigEntry::enumeration("side", "Side", "help", &["LEFT", "RIGHT"], "LEFT"),
    ];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "position",
        label: "Position",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    fn editor() -> PositionEditor {
        PositionEditor::new(
            "offset",
            "anchor",
            "side",
            Rect::new(0.0, 0.0, 160.0, 110.0),
        )
    }

    #[test]
    fn hotbar_widget_sits_beside_the_mark() {
        let runtime = ConfigRuntime::in_memory(&SCHEMA);
        let editor = editor();
        let screen = editor.screen_rect();
        let widget = editor.widget_rect(&runtime, screen);
        // Left of the hotbar's center, above the bottom.
        assert!(widget.right() < screen.x + screen.w / 2.0 - 91.0 / 4.0);
        assert!(widget.bottom() < screen.bottom() - 14.0);
    }

    #[test]
    fn dragging_updates_the_offset() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut editor = editor();
        let screen = editor.screen_rect();
        let widget = editor.widget_rect(&runtime, screen);
        let center = widget.center();
        let grab = InputEvent::Press {
            pos: center,
            button: 0,
        };
        assert!(editor.input(&grab, &mut runtime).consumed);
        assert!(editor.dragging);
        let drag = InputEvent::Drag {
            pos: [center[0] - 20.0, center[1] - 8.0],
            button: 0,
            delta: [-20.0, -8.0],
        };
        assert!(editor.input(&drag, &mut runtime).changed);
        let (ox, oy) = runtime.position("offset");
        // A positive X offset moves away from the hotbar (further left on
        // the left side), a positive Y offset moves down.
        assert!(
            ox > 0,
            "dragging left moves the widget away from the hotbar ({ox})"
        );
        // Bottom anchors measure Y upward, like the reference mod.
        assert!(oy > 0, "dragging up moves the widget up ({oy})");
    }
}
