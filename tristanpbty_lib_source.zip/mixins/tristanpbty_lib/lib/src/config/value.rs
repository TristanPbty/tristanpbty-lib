//! The typed value a configuration entry holds.
//!
//! The set is deliberately small and closed: booleans, integers, floats,
//! strings, closed enumerations, colors, keybindings and positions. Every
//! variant serialises through [`crate::json::Json`] without loss, and a
//! display label can be derived for the configuration screen.

use crate::utils::{argb, channels};
use std::borrow::Cow;

/// A configuration value.
///
/// The text variants borrow their default (`"HOTBAR"`), so a schema can be
/// built in a `static` without allocation, and own what they read from a
/// file.
#[derive(Clone, Debug, PartialEq)]
pub enum ConfigValue {
    Bool(bool),
    Int(i64),
    Float(f64),
    Str(Cow<'static, str>),
    /// A value from a closed set, stored by its name (`"LEFT"`).
    Enum(Cow<'static, str>),
    /// An opaque 0xRRGGBB color (alpha managed by the widgets).
    Color(u32),
    /// A keybinding in Horizon's naming (`key.keyboard.h`).
    Keybind(Cow<'static, str>),
    /// A `(x, y)` offset pair in GUI pixels.
    Position(i32, i32),
    /// A scale factor.
    Scale(f32),
}

impl ConfigValue {
    /// A borrowed text value, const-constructible for schema defaults.
    pub const fn enum_name(name: &'static str) -> ConfigValue {
        ConfigValue::Enum(Cow::Borrowed(name))
    }

    /// A borrowed keybind default.
    pub const fn keybind_name(name: &'static str) -> ConfigValue {
        ConfigValue::Keybind(Cow::Borrowed(name))
    }
}

impl ConfigValue {
    /// The kind's name, for messages.
    pub fn kind(&self) -> &'static str {
        match self {
            ConfigValue::Bool(_) => "boolean",
            ConfigValue::Int(_) => "integer",
            ConfigValue::Float(_) => "float",
            ConfigValue::Str(_) => "string",
            ConfigValue::Enum(_) => "enum",
            ConfigValue::Color(_) => "color",
            ConfigValue::Keybind(_) => "keybind",
            ConfigValue::Position(_, _) => "position",
            ConfigValue::Scale(_) => "scale",
        }
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            ConfigValue::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_i64(&self) -> Option<i64> {
        match self {
            ConfigValue::Int(i) => Some(*i),
            ConfigValue::Float(f) if f.fract() == 0.0 => Some(*f as i64),
            _ => None,
        }
    }

    pub fn as_f64(&self) -> Option<f64> {
        match self {
            ConfigValue::Int(i) => Some(*i as f64),
            ConfigValue::Float(f) => Some(*f),
            ConfigValue::Scale(s) => Some(*s as f64),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            ConfigValue::Str(s) | ConfigValue::Enum(s) | ConfigValue::Keybind(s) => Some(s),
            _ => None,
        }
    }

    /// The owned form of a text value, for storing what a file or a widget
    /// produced.
    pub fn text(value: impl Into<Cow<'static, str>>) -> ConfigValue {
        ConfigValue::Str(value.into())
    }

    pub fn as_color(&self) -> Option<u32> {
        match self {
            ConfigValue::Color(c) => Some(*c),
            _ => None,
        }
    }

    pub fn as_position(&self) -> Option<(i32, i32)> {
        match self {
            ConfigValue::Position(x, y) => Some((*x, *y)),
            _ => None,
        }
    }

    pub fn as_scale(&self) -> Option<f32> {
        match self {
            ConfigValue::Scale(s) => Some(*s),
            ConfigValue::Float(f) => Some(*f as f32),
            _ => None,
        }
    }

    /// The value as a short human-readable string for the config screen.
    pub fn display(&self) -> String {
        match self {
            ConfigValue::Bool(b) => if *b { "on" } else { "off" }.to_string(),
            ConfigValue::Int(i) => i.to_string(),
            ConfigValue::Float(f) => format_float(*f),
            ConfigValue::Str(s) | ConfigValue::Enum(s) => s.to_string(),
            ConfigValue::Keybind(k) => keybind_label(k),
            ConfigValue::Color(c) => {
                let (_, r, g, b) = channels(*c);
                format!("#{:02X}{:02X}{:02X}", r, g, b)
            }
            ConfigValue::Position(x, y) => format!("{x}, {y}"),
            ConfigValue::Scale(s) => format!("{}x", format_float(*s as f64)),
        }
    }
}

/// Formats a float without a trailing `.0` when it is whole.
pub fn format_float(f: f64) -> String {
    if f.fract() == 0.0 && f.abs() < 1e15 {
        format!("{}", f as i64)
    } else {
        let s = format!("{f:.3}");
        s.trim_end_matches('0').trim_end_matches('.').to_string()
    }
}

/// Renders a Horizon key name (`key.keyboard.h`) the way the Controls screen
/// shows it, without knowing the game's translation table: the last path
/// segment, capitalised, with the common `keyboard`/`mouse` prefixes dropped.
pub fn keybind_label(key: &str) -> String {
    let last = key.rsplit('.').next().unwrap_or(key);
    let text = last.replace(['_', '-'], " ");
    let mut chars = text.chars();
    match chars.next() {
        Some(first) => first.to_uppercase().collect::<String>() + chars.as_str(),
        None => String::new(),
    }
}

/// Parses a `#RRGGBB` or `RRGGBB` color; used by the color picker's field.
pub fn parse_color(text: &str) -> Option<u32> {
    let hex = text.strip_prefix('#').unwrap_or(text);
    if hex.len() != 6 || !hex.chars().all(|c| c.is_ascii_hexdigit()) {
        return None;
    }
    let r = u8::from_str_radix(&hex[0..2], 16).ok()?;
    let g = u8::from_str_radix(&hex[2..4], 16).ok()?;
    let b = u8::from_str_radix(&hex[4..6], 16).ok()?;
    Some(argb(0xFF, r, g, b))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn display_forms() {
        assert_eq!(ConfigValue::Bool(true).display(), "on");
        assert_eq!(ConfigValue::Int(-12).display(), "-12");
        assert_eq!(ConfigValue::Float(0.05).display(), "0.05");
        assert_eq!(ConfigValue::Float(2.0).display(), "2");
        assert_eq!(ConfigValue::Color(0x00FF_8000).display(), "#FF8000");
        assert_eq!(ConfigValue::Position(3, -4).display(), "3, -4");
        assert_eq!(ConfigValue::Scale(1.5).display(), "1.5x");
    }

    #[test]
    fn keybind_labels() {
        assert_eq!(keybind_label("key.keyboard.h"), "H");
        assert_eq!(keybind_label("key.keyboard.left_shift"), "Left shift");
        assert_eq!(keybind_label("key.mouse.button_1"), "Button 1");
    }

    #[test]
    fn color_parsing() {
        assert_eq!(parse_color("#FF8000"), Some(0xFFFF_8000));
        assert_eq!(parse_color("ff8000"), Some(0xFFFF_8000));
        assert_eq!(parse_color("#fff"), None);
        assert_eq!(parse_color("nope"), None);
    }

    #[test]
    fn numeric_conversions() {
        assert_eq!(ConfigValue::Int(7).as_f64(), Some(7.0));
        assert_eq!(ConfigValue::Float(7.0).as_i64(), Some(7));
        assert_eq!(ConfigValue::Float(7.5).as_i64(), None);
        assert_eq!(ConfigValue::Scale(2.0).as_f64(), Some(2.0));
    }
}
