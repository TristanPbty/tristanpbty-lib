//! The widget model: host-independent controls that consume abstract input
//! events and produce an abstract draw list.
//!
//! A widget never touches the game. It reads and writes a
//! [`crate::config::runtime::ConfigRuntime`], draws itself as
//! [`DrawCmd`] values the host interprets with Horizon's GUI helpers, and
//! reports whether it consumed an [`InputEvent`] so the host knows whether
//! to cancel the screen's own handling.
//!
//! The concrete controls live in sibling modules; [`mod.rs`] also provides
//! the shared drawing vocabulary (panels, labels, hovered states) so every
//! control looks like part of one screen. The [`cycle_button`] is the plain
//! vanilla-style option button the configuration screens are built from.

pub mod button;
pub mod color_picker;
pub mod cycle_button;
pub mod dropdown;
pub mod keybind;
pub mod number_input;
pub mod position_editor;
pub mod scale_selector;
pub mod slider;
pub mod toggle;

use crate::config::runtime::ConfigRuntime;
use crate::utils::Rect;

/// One abstract draw command. The host turns these into `native_fill`,
/// `native_sprite`, `native_text` and `native_item_stack` calls.
#[derive(Clone, Debug, PartialEq)]
pub enum DrawCmd {
    /// A solid rectangle in GUI pixels, `0xAARRGGBB`.
    Fill { rect: [f32; 4], argb: u32 },
    /// Part `src` (in the sprite's own pixels) of atlas sprite `name`,
    /// stretched into `dst` (GUI pixels), tinted `0xAARRGGBB` (white keeps
    /// the sprite's own colors).
    Sprite {
        name: String,
        src: [f32; 4],
        dst: [f32; 4],
        tint: u32,
    },
    /// A text line at `at` (its top-left), opaque `0xRRGGBB`. `center_x`,
    /// when set, is the horizontal center line the text is centered on.
    Text {
        text: String,
        at: [f32; 2],
        rgb: u32,
        shadow: bool,
        center_x: Option<f32>,
    },
    /// The item stack `stack` of the host's snapshot, at `at`, `size` GUI
    /// pixels square (16 in a slot).
    Item {
        stack: usize,
        at: [f32; 2],
        size: f32,
    },
}

/// An input event, already translated to GUI pixels and abstract names.
///
/// The lifetime lets a key event borrow the key's name from the host's hook
/// arguments instead of allocating per event.
#[derive(Clone, Copy, Debug, PartialEq)]
pub enum InputEvent<'a> {
    /// A mouse button went down: 0 left, 1 right, 2 middle.
    Press { pos: [f32; 2], button: i32 },
    /// A mouse button came up.
    Release { pos: [f32; 2], button: i32 },
    /// A drag: movement with a held button (deltas in GUI pixels).
    Drag {
        pos: [f32; 2],
        button: i32,
        delta: [f32; 2],
    },
    /// A scroll step: `steps[1]` is the vertical one (positive away).
    Scroll { pos: [f32; 2], steps: [f32; 2] },
    /// A named key press (`key.keyboard.h`); `text` is what it types, if
    /// anything.
    Key { name: &'a str, text: Option<char> },
}

/// What a widget did with an event.
#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct InputResult {
    /// The widget claims the event; the host cancels the screen's handling.
    pub consumed: bool,
    /// A setting changed; the host may refresh dependent UI.
    pub changed: bool,
}

impl InputResult {
    pub fn ignored() -> InputResult {
        InputResult::default()
    }

    pub fn consumed() -> InputResult {
        InputResult {
            consumed: true,
            changed: false,
        }
    }

    pub fn changed() -> InputResult {
        InputResult {
            consumed: true,
            changed: true,
        }
    }

    /// A consumed event that changed a setting only when `value` is true.
    pub fn changed_if(value: bool) -> InputResult {
        if value {
            InputResult::changed()
        } else {
            InputResult::consumed()
        }
    }
}

/// A control on the configuration screen.
pub trait Widget {
    /// The settings key the widget edits, for focus and testing.
    fn key(&self) -> &str;

    /// The widget's interactive area.
    fn rect(&self) -> Rect;

    /// Draws the widget into `out`. `focused` is whether the pointer is over
    /// it (the only hover state the config screen tracks).
    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime);

    /// Handles an event. Widgets are single-shot: they receive the event and
    /// answer, with no hidden modal state of their own beyond their fields.
    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult;
}

// ---------------------------------------------------------------------------
// The shared drawing vocabulary.
// ---------------------------------------------------------------------------

/// The panel background of a control, vanilla-chat dark.
pub const PANEL: u32 = 0xC010_1010;
/// A slightly lighter panel for the hovered state.
pub const PANEL_HOVER: u32 = 0xC026_2626;
/// The active accent (the vanilla button highlight green).
pub const ACCENT: u32 = 0xFF30_7C30;
/// The track of a slider or toggle.
pub const TRACK: u32 = 0xFF1A_1A1A;
/// Opaque label text.
pub const TEXT: u32 = 0xFFFF_FFFF;
/// Dimmed help text.
pub const TEXT_DIM: u32 = 0xFFA0_A0A0;
/// The border of a control.
pub const BORDER: u32 = 0xFF5A_5A5A;

/// A control's border: 1 pixel around `rect`.
pub fn draw_border(out: &mut Vec<DrawCmd>, rect: Rect, argb: u32) {
    let (x, y, w, h) = (rect.x, rect.y, rect.w, rect.h);
    out.push(DrawCmd::Fill {
        rect: [x, y, w, 1.0],
        argb,
    });
    out.push(DrawCmd::Fill {
        rect: [x, y + h - 1.0, w, 1.0],
        argb,
    });
    out.push(DrawCmd::Fill {
        rect: [x, y, 1.0, h],
        argb,
    });
    out.push(DrawCmd::Fill {
        rect: [x + w - 1.0, y, 1.0, h],
        argb,
    });
}

/// A filled panel with a border.
pub fn draw_panel(out: &mut Vec<DrawCmd>, rect: Rect, fill: u32, border: u32) {
    out.push(DrawCmd::Fill {
        rect: [rect.x, rect.y, rect.w, rect.h],
        argb: fill,
    });
    draw_border(out, rect, border);
}

/// The label of a control, vertically centered on its row.
pub fn draw_label(out: &mut Vec<DrawCmd>, text: &str, at: [f32; 2], rgb: u32) {
    out.push(DrawCmd::Text {
        text: text.to_string(),
        at,
        rgb,
        shadow: true,
        center_x: None,
    });
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn input_results_combine() {
        assert_eq!(InputResult::ignored(), InputResult::default());
        assert!(InputResult::changed().consumed);
        assert!(InputResult::changed().changed);
        assert!(InputResult::consumed().consumed);
        assert!(!InputResult::consumed().changed);
    }

    #[test]
    fn border_draws_four_edges() {
        let mut out = Vec::new();
        draw_border(&mut out, Rect::new(0.0, 0.0, 10.0, 8.0), 0xFF00_0000);
        assert_eq!(out.len(), 4);
        for cmd in &out {
            assert!(matches!(cmd, DrawCmd::Fill { .. }));
        }
    }
}
