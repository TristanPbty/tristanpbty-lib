//! The declarative description of a mod's configuration: entries with types,
//! defaults, ranges and labels, grouped into tabs for the config screen.
//!
//! A schema is data, not code: the persistence layer validates files against
//! it, the widget model builds controls from it, and the migration system
//! knows which keys belong to which version.

use crate::config::value::ConfigValue;

/// How one entry's value may move.
#[derive(Clone, Debug, PartialEq)]
pub enum Limits {
    /// Any value of the type.
    None,
    /// Integers inside `lo..=hi`.
    Int(i64, i64),
    /// Floats inside `lo..=hi`, stepping by `step` in the slider.
    Float(f64, f64, f64),
    /// A value from a closed set of names.
    Enum(&'static [&'static str]),
    /// A scale factor inside `lo..=hi`.
    Scale(f32, f32),
}

/// One configuration entry.
#[derive(Clone, Debug)]
pub struct ConfigEntry {
    /// The JSON key and the settings id.
    pub id: &'static str,
    /// The label shown in the config screen.
    pub label: &'static str,
    /// A one-line help text shown when the entry is focused.
    pub help: &'static str,
    pub default: ConfigValue,
    pub limits: Limits,
}

impl ConfigEntry {
    pub const fn bool(id: &'static str, label: &'static str, help: &'static str, v: bool) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::Bool(v),
            limits: Limits::None,
        }
    }

    pub const fn int(
        id: &'static str,
        label: &'static str,
        help: &'static str,
        v: i64,
        lo: i64,
        hi: i64,
    ) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::Int(v),
            limits: Limits::Int(lo, hi),
        }
    }

    pub const fn float(
        id: &'static str,
        label: &'static str,
        help: &'static str,
        v: f64,
        lo: f64,
        hi: f64,
        step: f64,
    ) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::Float(v),
            limits: Limits::Float(lo, hi, step),
        }
    }

    pub const fn enumeration(
        id: &'static str,
        label: &'static str,
        help: &'static str,
        variants: &'static [&'static str],
        v: &'static str,
    ) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::enum_name(v),
            limits: Limits::Enum(variants),
        }
    }

    pub const fn color(id: &'static str, label: &'static str, help: &'static str, v: u32) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::Color(v),
            limits: Limits::None,
        }
    }

    pub const fn keybind(
        id: &'static str,
        label: &'static str,
        help: &'static str,
        v: &'static str,
    ) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::keybind_name(v),
            limits: Limits::None,
        }
    }

    pub const fn position(
        id: &'static str,
        label: &'static str,
        help: &'static str,
        x: i32,
        y: i32,
    ) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::Position(x, y),
            limits: Limits::None,
        }
    }

    pub const fn scale(
        id: &'static str,
        label: &'static str,
        help: &'static str,
        v: f32,
        lo: f32,
        hi: f32,
    ) -> Self {
        ConfigEntry {
            id,
            label,
            help,
            default: ConfigValue::Scale(v),
            limits: Limits::Scale(lo, hi),
        }
    }
}

impl Limits {
    /// The closed set of an enumeration, if this is one.
    pub fn variants(&self) -> Option<&'static [&'static str]> {
        match self {
            Limits::Enum(v) => Some(v),
            _ => None,
        }
    }
}

/// A tab of the configuration screen.
#[derive(Clone, Debug)]
pub struct ConfigTab {
    pub id: &'static str,
    pub label: &'static str,
    pub entries: &'static [ConfigEntry],
}

/// A whole mod configuration: a versioned set of tabs.
#[derive(Clone, Debug)]
pub struct ConfigSchema {
    pub mod_id: &'static str,
    /// The schema version written into the file; migrations bring older
    /// files up to it.
    pub version: u32,
    pub tabs: &'static [ConfigTab],
}

impl ConfigSchema {
    /// Every entry of every tab, in order.
    pub fn entries(&self) -> impl Iterator<Item = &ConfigEntry> {
        self.tabs.iter().flat_map(|t| t.entries.iter())
    }

    pub fn entry(&self, id: &str) -> Option<&ConfigEntry> {
        self.entries().find(|e| e.id == id)
    }

    /// The default value of `id`, if the schema knows it.
    pub fn default_of(&self, id: &str) -> Option<ConfigValue> {
        self.entry(id).map(|e| e.default.clone())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const GENERAL: &[ConfigEntry] = &[ConfigEntry::bool(
        "enabled",
        "Enabled",
        "Master switch",
        true,
    )];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: GENERAL,
    }];

    #[test]
    fn schema_lookup() {
        let schema = ConfigSchema {
            mod_id: "test_mod",
            version: 1,
            tabs: TABS,
        };
        assert_eq!(schema.default_of("enabled"), Some(ConfigValue::Bool(true)));
        assert_eq!(schema.default_of("missing"), None);
        assert_eq!(schema.entry("enabled").unwrap().label, "Enabled");
    }
}
