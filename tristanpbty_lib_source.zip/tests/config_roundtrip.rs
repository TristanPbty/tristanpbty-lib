//! End-to-end test of the configuration system on an in-memory disk: a file
//! is written, reloaded, migrated, validated and repaired.

use std::collections::BTreeMap;
use std::path::Path;
use tristanpbty_lib::config::persistence::{Disk, MemoryDisk, load, save};
use tristanpbty_lib::config::runtime::ConfigRuntime;
use tristanpbty_lib::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};
use tristanpbty_lib::config::value::ConfigValue;
use tristanpbty_lib::json::{Json, parse};

const ANCHORS: &[&str] = &["TOP_CENTER", "TOP", "CENTER", "BOTTOM", "HOTBAR"];
const ENTRIES: &[ConfigEntry] = &[
    ConfigEntry::bool("enabled", "Enabled", "help", true),
    ConfigEntry::enumeration("anchor", "Anchor", "help", ANCHORS, "HOTBAR"),
    ConfigEntry::int("offsetX", "X offset", "help", 0, -500, 500),
    ConfigEntry::scale("scale", "Scale", "help", 1.0, 0.5, 2.0),
    ConfigEntry::keybind("menuKey", "Menu key", "help", "key.keyboard.h"),
];
const TABS: &[ConfigTab] = &[ConfigTab {
    id: "general",
    label: "General",
    entries: ENTRIES,
}];
static SCHEMA: ConfigSchema = ConfigSchema {
    mod_id: "tristanpbty_test",
    version: 1,
    tabs: TABS,
};

#[test]
fn a_full_setting_round_trip() {
    let disk = MemoryDisk::default();
    let path = Path::new("/config/tristanpbty_test.json");
    let mut runtime =
        ConfigRuntime::with_storage(&SCHEMA, Box::new(disk.clone()), path.into(), &[]);
    assert!(runtime.bool("enabled"));
    runtime.set("anchor", ConfigValue::Enum("TOP_CENTER".into()));
    runtime.set("offsetX", ConfigValue::Int(-40));
    runtime.set("scale", ConfigValue::Scale(1.5));
    runtime.set("menuKey", ConfigValue::Keybind("key.keyboard.b".into()));
    runtime.save(1);
    let text = disk.read(path).expect("saved");
    assert!(text.contains("\"anchor\": \"TOP_CENTER\""));
    assert!(text.contains("\"scale\": 1.5"));
    // A second runtime over the same file sees the same settings.
    let reloaded = ConfigRuntime::with_storage(&SCHEMA, Box::new(disk), path.into(), &[]);
    assert_eq!(reloaded.text("anchor"), "TOP_CENTER");
    assert_eq!(reloaded.int("offsetX"), -40);
    assert_eq!(reloaded.scale("scale"), 1.5);
    assert_eq!(reloaded.text("menuKey"), "key.keyboard.b");
}

#[test]
fn a_hand_edited_file_is_repaired_to_valid_values() {
    let disk = MemoryDisk::default();
    let path = Path::new("/config/tristanpbty_test.json");
    disk.write(
        path,
        b"{\"version\": 1, \"anchor\": \"MIDDLE\", \"offsetX\": 9999, \"scale\": 9.9, \"leftOver\": null}",
    )
    .unwrap();
    let loaded = load(&disk, path, &SCHEMA, &[]).unwrap();
    assert_eq!(loaded.problems.len(), 4, "{:?}", loaded.problems);
    assert_eq!(loaded.values["anchor"], ConfigValue::Enum("HOTBAR".into()));
    assert_eq!(loaded.values["offsetX"], ConfigValue::Int(0));
    assert_eq!(loaded.values["scale"], ConfigValue::Scale(1.0));
    // Saving repairs the file: the unknown key is gone, the values are valid.
    save(&disk, path, &SCHEMA, &loaded.values).unwrap();
    let repaired = load(&disk, path, &SCHEMA, &[]).unwrap();
    assert!(repaired.problems.is_empty());
}

#[test]
fn the_version_field_is_written_first_and_stable() {
    let disk = MemoryDisk::default();
    let path = Path::new("/config/tristanpbty_test.json");
    save(&disk, path, &SCHEMA, &std::collections::BTreeMap::new()).unwrap();
    let text = disk.read(path).unwrap();
    let value = parse(&text).unwrap();
    assert_eq!(value.get("version").and_then(Json::as_i64), Some(1));
    let keys: Vec<&String> = value.as_object().unwrap().keys().collect();
    assert_eq!(keys.first().map(|k| k.as_str()), Some("version"));
    // Saving again yields byte-identical output (deterministic serialisation).
    let before = disk.read(path).unwrap();
    let empty: BTreeMap<String, ConfigValue> = BTreeMap::new();
    save(&disk, path, &SCHEMA, &empty).unwrap();
    // The second save went through the .bak dance; the final file is equal.
    let after = disk.read(path).unwrap();
    assert_eq!(before, after);
}

#[test]
fn a_migration_renames_an_old_key() {
    // A fabricated v0 file (before the key was called `anchor`).
    fn rename(m: &mut BTreeMap<String, Json>) {
        if let Some(v) = m.remove("attach") {
            m.insert("anchor".to_string(), v);
        }
    }
    let steps = [tristanpbty_lib::config::Migration {
        from: 0,
        run: rename,
        note: "renamed `attach` to `anchor`",
    }];
    let disk = MemoryDisk::default();
    let path = Path::new("/config/tristanpbty_test.json");
    disk.write(path, b"{\"version\": 0, \"attach\": \"TOP\"}")
        .unwrap();
    let loaded = load(&disk, path, &SCHEMA, &steps).unwrap();
    assert_eq!(loaded.migrations, vec!["renamed `attach` to `anchor`"]);
    assert_eq!(loaded.values["anchor"], ConfigValue::Enum("TOP".into()));
}
