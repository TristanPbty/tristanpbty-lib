//! The cycle button: the plain option button of vanilla settings screens.
//!
//! One gray rectangle, one centered line — `Label: Value` — and one gesture:
//! click (or scroll) to step to the next value. Booleans flip, enumerations
//! wrap around their variants, and ranged numbers step by a coarse stride
//! and stop at their limits. No panels to open, no fields to type into, no
//! drag state to lose: the value always shows on the button itself.

use super::{
    ACCENT, BORDER, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, Widget, draw_border,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::schema::{ConfigEntry, Limits};
use crate::config::value::ConfigValue;
use crate::utils::Rect;

/// A full-width option button cycling one configuration entry.
pub struct CycleButton {
    key: String,
    rect: Rect,
    label: String,
}

impl CycleButton {
    pub fn new(key: &str, label: &str, rect: Rect) -> CycleButton {
        CycleButton {
            key: key.to_string(),
            rect,
            label: label.to_string(),
        }
    }
}

impl Widget for CycleButton {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if focused { PANEL_HOVER } else { PANEL },
        });
        draw_border(out, self.rect, if focused { ACCENT } else { BORDER });
        let value = runtime
            .get(&self.key)
            .cloned()
            .or_else(|| {
                runtime
                    .schema()
                    .entry(&self.key)
                    .map(|entry| entry.default.clone())
            })
            .unwrap_or(ConfigValue::Bool(false));
        out.push(DrawCmd::Text {
            text: format!("{}: {}", self.label, display_value(&value)),
            at: [0.0, self.rect.y + (self.rect.h - 8.0) / 2.0],
            rgb: TEXT,
            shadow: true,
            center_x: Some(self.rect.center()[0]),
        });
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        let forward = match event {
            InputEvent::Press { pos, button } if self.rect.contains(*pos) => match *button {
                0 => Some(true),
                1 | 2 => Some(false),
                _ => None,
            },
            // A scroll steps too, the way vanilla's cycling buttons do: a
            // notch away from the player is the previous value.
            InputEvent::Scroll { pos, steps } if self.rect.contains(*pos) => {
                if steps[1] > 0.0 {
                    Some(false)
                } else if steps[1] < 0.0 {
                    Some(true)
                } else {
                    None
                }
            }
            _ => None,
        };
        let Some(forward) = forward else {
            return InputResult::ignored();
        };
        let Some(entry) = runtime.schema().entry(&self.key) else {
            return InputResult::ignored();
        };
        let current = runtime
            .get(&self.key)
            .cloned()
            .unwrap_or_else(|| entry.default.clone());
        let next = step_value(entry, &current, forward);
        InputResult::changed_if(runtime.set(&self.key, next))
    }
}

/// The value as the button writes it: `On`/`Off` for booleans, a prettified
/// name for enumerations, plain numbers otherwise.
pub fn display_value(value: &ConfigValue) -> String {
    match value {
        ConfigValue::Bool(true) => "On".to_string(),
        ConfigValue::Bool(false) => "Off".to_string(),
        ConfigValue::Enum(name) | ConfigValue::Keybind(name) => prettify(name),
        other => other.display(),
    }
}

/// `ROUNDED_CORNERS` reads as `Rounded corners` on a button — sentence
/// case, the way vanilla's own option values read.
pub fn prettify(name: &str) -> String {
    let mut out = String::with_capacity(name.len());
    for (i, word) in name.split(['_', '-']).enumerate() {
        if i > 0 {
            out.push(' ');
        }
        let mut chars = word.chars();
        if let Some(first) = chars.next() {
            if i == 0 {
                out.extend(first.to_uppercase());
            } else {
                out.extend(first.to_lowercase());
            }
            out.push_str(&chars.as_str().to_lowercase());
        }
    }
    out
}

/// One value of `entry` past `current`, forward or back.
///
/// Booleans flip; enumerations wrap around their variants; ranged numbers
/// take a coarse stride (`Limits::Float`'s own step when it has one) and
/// stop at their ends — a number is a range, not a loop, so it never wraps
/// around to a value on the far side.
pub fn step_value(entry: &ConfigEntry, current: &ConfigValue, forward: bool) -> ConfigValue {
    let (sign, sign_i): (f64, i64) = if forward { (1.0, 1) } else { (-1.0, -1) };
    match current {
        ConfigValue::Bool(b) => ConfigValue::Bool(!*b),
        ConfigValue::Enum(name) => {
            let Limits::Enum(variants) = &entry.limits else {
                return current.clone();
            };
            if variants.is_empty() {
                return current.clone();
            }
            let at = variants.iter().position(|v| v == name).unwrap_or(0);
            let len = variants.len() as i64;
            let next = (at as i64 + sign_i).rem_euclid(len) as usize;
            ConfigValue::Enum(std::borrow::Cow::Borrowed(variants[next]))
        }
        ConfigValue::Int(i) => {
            let Limits::Int(lo, hi) = &entry.limits else {
                return current.clone();
            };
            // A stride that crosses the range in about a hundred clicks at
            // most: ten pixels at a time for a ±500 offset, five points for
            // a durability threshold.
            let stride = ((hi - lo) / 100).max(1);
            let next = *i + sign_i * stride;
            ConfigValue::Int(next.clamp(*lo, *hi))
        }
        ConfigValue::Float(f) => {
            let Limits::Float(lo, hi, step) = &entry.limits else {
                return current.clone();
            };
            let stride = if *step > 0.0 { *step } else { (hi - lo) / 20.0 };
            let next = *f + sign * stride;
            ConfigValue::Float(next.clamp(*lo, *hi))
        }
        ConfigValue::Scale(s) => {
            let Limits::Scale(lo, hi) = &entry.limits else {
                return current.clone();
            };
            // The quarter-step ladder 0.5 … 2.0 covers the whole range.
            let next = *s + sign as f32 * 0.25;
            ConfigValue::Scale(next.clamp(*lo, *hi))
        }
        other => other.clone(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[
        ConfigEntry::bool("enabled", "Armor HUD", "help", true),
        ConfigEntry::enumeration(
            "style",
            "Slot style",
            "help",
            &["HOTBAR", "ROUNDED_CORNERS", "NONE"],
            "HOTBAR",
        ),
        ConfigEntry::int("offsetX", "X offset", "help", 0, -500, 500),
        ConfigEntry::float("ratio", "Ratio", "help", 0.1, 0.0, 1.0, 0.05),
        ConfigEntry::scale("scale", "Scale", "help", 1.0, 0.5, 2.0),
    ];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    fn button(key: &str) -> CycleButton {
        CycleButton::new(key, "Label", Rect::new(0.0, 0.0, 200.0, 20.0))
    }

    fn click(key: &str, mouse: i32, runtime: &mut ConfigRuntime) -> InputResult {
        button(key).input(
            &InputEvent::Press {
                pos: [100.0, 10.0],
                button: mouse,
            },
            runtime,
        )
    }

    fn scroll(key: &str, steps: f32, runtime: &mut ConfigRuntime) -> InputResult {
        button(key).input(
            &InputEvent::Scroll {
                pos: [100.0, 10.0],
                steps: [0.0, steps],
            },
            runtime,
        )
    }

    #[test]
    fn clicking_flips_a_boolean() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(runtime.bool("enabled"));
        assert!(click("enabled", 0, &mut runtime).changed);
        assert!(!runtime.bool("enabled"));
        // A right click flips it back.
        assert!(click("enabled", 1, &mut runtime).changed);
        assert!(runtime.bool("enabled"));
        // Outside the button: nothing.
        let miss = button("enabled").input(
            &InputEvent::Press {
                pos: [500.0, 10.0],
                button: 0,
            },
            &mut runtime,
        );
        assert_eq!(miss, InputResult::ignored());
    }

    #[test]
    fn enumerations_wrap_both_ways() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(click("style", 0, &mut runtime).changed);
        assert_eq!(runtime.text("style"), "ROUNDED_CORNERS");
        assert!(click("style", 0, &mut runtime).changed);
        assert_eq!(runtime.text("style"), "NONE");
        // Wraps around the end…
        assert!(click("style", 0, &mut runtime).changed);
        assert_eq!(runtime.text("style"), "HOTBAR");
        // …and back over the start.
        assert!(click("style", 1, &mut runtime).changed);
        assert_eq!(runtime.text("style"), "NONE");
    }

    #[test]
    fn scrolling_steps_like_vanillas_cycling_buttons() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        // A notch away from the player is the previous value.
        assert!(scroll("style", 1.0, &mut runtime).changed);
        assert_eq!(runtime.text("style"), "NONE");
        assert!(scroll("style", -1.0, &mut runtime).changed);
        assert_eq!(runtime.text("style"), "HOTBAR");
        // No vertical step: nothing.
        assert_eq!(scroll("style", 0.0, &mut runtime), InputResult::ignored());
    }

    #[test]
    fn integers_stride_and_stop_at_their_limits() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        // The ±500 range strides by ten.
        for _ in 0..3 {
            assert!(click("offsetX", 0, &mut runtime).changed);
        }
        assert_eq!(runtime.int("offsetX"), 30);
        assert!(click("offsetX", 1, &mut runtime).changed);
        assert_eq!(runtime.int("offsetX"), 20);
        // Clamped at the top after fifty clicks, not wrapped.
        for _ in 0..60 {
            click("offsetX", 0, &mut runtime);
        }
        assert_eq!(runtime.int("offsetX"), 500);
        assert!(click("offsetX", 0, &mut runtime).consumed);
        assert_eq!(runtime.int("offsetX"), 500);
    }

    #[test]
    fn floats_step_by_the_schema_step() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(click("ratio", 1, &mut runtime).changed);
        assert_eq!(runtime.float("ratio"), 0.05);
        assert!(click("ratio", 0, &mut runtime).changed);
        assert_eq!(runtime.float("ratio"), 0.1);
        // Clamped at zero, not wrapped to one.
        for _ in 0..5 {
            click("ratio", 1, &mut runtime);
        }
        assert_eq!(runtime.float("ratio"), 0.0);
    }

    #[test]
    fn scales_climb_the_quarter_ladder() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(click("scale", 0, &mut runtime).changed);
        assert_eq!(runtime.scale("scale"), 1.25);
        for _ in 0..4 {
            click("scale", 0, &mut runtime);
        }
        assert_eq!(runtime.scale("scale"), 2.0);
        assert!(click("scale", 0, &mut runtime).consumed);
        assert_eq!(runtime.scale("scale"), 2.0);
        assert!(click("scale", 1, &mut runtime).changed);
        assert_eq!(runtime.scale("scale"), 1.75);
    }

    #[test]
    fn the_button_wears_its_label_and_value() {
        let runtime = ConfigRuntime::in_memory(&SCHEMA);
        let cycle = CycleButton::new("enabled", "Armor HUD", Rect::new(0.0, 0.0, 200.0, 20.0));
        let mut out = Vec::new();
        cycle.draw(&mut out, false, &runtime);
        let line = out.iter().find_map(|d| match d {
            DrawCmd::Text { text, .. } => Some(text.clone()),
            _ => None,
        });
        assert_eq!(line.as_deref(), Some("Armor HUD: On"));
        // The same button hovered: the same line, the accent border.
        let mut hovered = Vec::new();
        cycle.draw(&mut hovered, true, &runtime);
        let borders = |draws: &[DrawCmd], argb: u32| {
            draws
                .iter()
                .filter(|d| matches!(d, DrawCmd::Fill { argb: a, .. } if *a == argb))
                .count()
        };
        assert_eq!(borders(&out, BORDER), 4);
        assert_eq!(borders(&hovered, ACCENT), 4);
    }

    #[test]
    fn values_read_as_people_expect() {
        assert_eq!(display_value(&ConfigValue::Bool(true)), "On");
        assert_eq!(display_value(&ConfigValue::Bool(false)), "Off");
        assert_eq!(
            display_value(&ConfigValue::enum_name("ROUNDED_CORNERS")),
            "Rounded corners"
        );
        assert_eq!(display_value(&ConfigValue::enum_name("AUTO")), "Auto");
        assert_eq!(display_value(&ConfigValue::Int(-12)), "-12");
        assert_eq!(display_value(&ConfigValue::Float(0.05)), "0.05");
        assert_eq!(display_value(&ConfigValue::Scale(1.5)), "1.5x");
        assert_eq!(prettify("ALWAYS_LEAVE_SPACE"), "Always leave space");
        assert_eq!(prettify("IF_ANY_PRESENT"), "If any present");
        assert_eq!(prettify(""), "");
    }

    #[test]
    fn a_key_event_is_ignored() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let result = button("enabled").input(
            &InputEvent::Key {
                name: "key.keyboard.h",
                text: None,
            },
            &mut runtime,
        );
        assert_eq!(result, InputResult::ignored());
        assert!(runtime.bool("enabled"));
    }
}
