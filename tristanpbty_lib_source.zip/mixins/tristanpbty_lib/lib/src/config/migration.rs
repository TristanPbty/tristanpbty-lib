//! Versioned migrations: the steps that bring an old configuration file to
//! the schema's current version.
//!
//! A migration is a pure function over the JSON object, so it can be tested
//! without the filesystem. The runner applies them in order and refuses to
//! guess past a gap: a file newer than the schema is an error, not something
//! to truncate.

use crate::json::{Json, ParseError};
use std::collections::BTreeMap;
use std::fmt;

/// One step from version `from` to `from + 1`.
#[derive(Clone)]
pub struct Migration {
    pub from: u32,
    pub run: fn(&mut BTreeMap<String, Json>),
    /// A human-readable note of what changed, for the log.
    pub note: &'static str,
}

/// Applies `migrations` (sorted however they are stored) to a raw config
/// object whose `version` field says where it comes from, bringing it to
/// `target`. Returns the notes of the applied steps.
pub fn migrate(
    value: &mut BTreeMap<String, Json>,
    version: u32,
    target: u32,
    migrations: &[Migration],
) -> Result<Vec<&'static str>, MigrationError> {
    if version > target {
        return Err(MigrationError::NewerThanSchema { version, target });
    }
    let mut applied = Vec::new();
    let mut current = version;
    while current < target {
        let step = migrations
            .iter()
            .find(|m| m.from == current)
            .ok_or(MigrationError::MissingStep { from: current })?;
        (step.run)(value);
        applied.push(step.note);
        current += 1;
    }
    value.insert("version".to_string(), Json::number(target.to_string()));
    Ok(applied)
}

#[derive(Clone, Debug, PartialEq)]
pub enum MigrationError {
    /// The file was written by a newer mod.
    NewerThanSchema { version: u32, target: u32 },
    /// No migration from that version is registered.
    MissingStep { from: u32 },
}

impl fmt::Display for MigrationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            MigrationError::NewerThanSchema { version, target } => write!(
                f,
                "the file is version {version}, newer than this mod's schema {target}"
            ),
            MigrationError::MissingStep { from } => {
                write!(f, "no migration is registered from version {from}")
            }
        }
    }
}

impl std::error::Error for MigrationError {}

/// Reads the `version` field. A file with no marker is version 1 (the first
/// released schema carried none); an explicit `0` is honored so a migration
/// can start from the very first format.
pub fn version_of(value: &BTreeMap<String, Json>) -> u32 {
    value
        .get("version")
        .and_then(Json::as_i64)
        .map(|v| v.max(0) as u32)
        .unwrap_or(1)
}

/// A parse error paired with the file it came from.
#[derive(Clone, Debug)]
pub struct FileError {
    pub path: String,
    pub cause: ParseError,
}

impl fmt::Display for FileError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}: {}", self.path, self.cause)
    }
}

impl std::error::Error for FileError {}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::json::parse;

    #[test]
    fn applies_steps_in_order() {
        // A fabricated two-step history: v1 renamed a key, v2 added one.
        fn rename(m: &mut BTreeMap<String, Json>) {
            if let Some(v) = m.remove("oldName") {
                m.insert("newName".to_string(), v);
            }
        }
        fn add_key(m: &mut BTreeMap<String, Json>) {
            m.entry("added".to_string())
                .or_insert_with(|| Json::Bool(true));
        }
        let steps = [
            Migration {
                from: 1,
                run: rename,
                note: "renamed oldName to newName",
            },
            Migration {
                from: 2,
                run: add_key,
                note: "added `added`",
            },
        ];
        let value = parse("{\"oldName\":3}").unwrap();
        let map = value.as_object().cloned().unwrap();
        let mut map = map;
        let notes = migrate(&mut map, 1, 3, &steps).unwrap();
        assert_eq!(notes.len(), 2);
        assert_eq!(map.get("newName").and_then(Json::as_i64), Some(3));
        assert_eq!(map.get("added").and_then(Json::as_bool), Some(true));
        assert_eq!(map.get("version").and_then(Json::as_i64), Some(3));
    }

    #[test]
    fn refuses_files_from_the_future() {
        let mut map = BTreeMap::new();
        match migrate(&mut map, 7, 1, &[]) {
            Err(MigrationError::NewerThanSchema { version, target }) => {
                assert_eq!((version, target), (7, 1));
            }
            other => panic!("expected NewerThanSchema, got {other:?}"),
        }
    }

    #[test]
    fn refuses_missing_steps() {
        let mut map = BTreeMap::new();
        assert_eq!(
            migrate(&mut map, 2, 3, &[]),
            Err(MigrationError::MissingStep { from: 2 })
        );
    }

    #[test]
    fn version_defaults_to_one() {
        let map = BTreeMap::new();
        assert_eq!(version_of(&map), 1);
        let with = parse("{\"version\":4}").unwrap();
        assert_eq!(version_of(with.as_object().unwrap()), 4);
    }
}
