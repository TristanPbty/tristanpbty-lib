//! Equipment snapshots and durability math.
//!
//! The game side of a mod reads its player's armor and hands through
//! Horizon's helpers and hands the data here as plain values, so the HUD
//! layout is computed — and unit tested — without the game's types.

/// The equipment slots an armor HUD shows, in inventory order.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum SlotKind {
    Head,
    Chest,
    Legs,
    Feet,
    OffHand,
    MainHand,
}

impl SlotKind {
    /// The order the reference mods draw the armor in: head first.
    pub const ARMOR_ORDER: [SlotKind; 4] = [
        SlotKind::Head,
        SlotKind::Chest,
        SlotKind::Legs,
        SlotKind::Feet,
    ];

    /// The empty-slot icon sprite vanilla's inventory screen draws, without
    /// the `gui/sprites/container/slot/` prefix.
    pub fn empty_icon(self) -> &'static str {
        match self {
            SlotKind::Head => "helmet",
            SlotKind::Chest => "chestplate",
            SlotKind::Legs => "leggings",
            SlotKind::Feet => "boots",
            SlotKind::OffHand => "shield",
            SlotKind::MainHand => "",
        }
    }
}

/// A plain copy of one item stack: everything the HUD needs and nothing that
/// borrows from the game.
#[derive(Clone, Debug, PartialEq)]
pub struct StackInfo {
    /// The item id (`minecraft:iron_helmet`).
    pub item: String,
    pub count: u32,
    /// The damage already taken.
    pub damage: u32,
    /// The stack's maximum damage; 0 when the item has no durability.
    pub max_damage: u32,
    /// Whether the stack renders with the enchantment glint: the host's own
    /// foil check (`ItemStack.hasFoil` — an override component, the item's
    /// own glint, or a non-empty enchantments component), carried as a plain
    /// value so the game side can rebuild a stack that shimmers. The layout
    /// itself does not branch on it.
    pub glint: bool,
}

impl StackInfo {
    pub fn empty() -> StackInfo {
        StackInfo {
            item: "minecraft:air".to_string(),
            count: 0,
            damage: 0,
            max_damage: 0,
            glint: false,
        }
    }

    pub fn is_empty(&self) -> bool {
        self.item == "minecraft:air" || self.count == 0
    }

    pub fn is_damageable(&self) -> bool {
        self.max_damage > 0 && !self.is_empty()
    }

    /// The durability left.
    pub fn remaining(&self) -> u32 {
        if self.is_damageable() {
            self.max_damage.saturating_sub(self.damage)
        } else {
            0
        }
    }

    /// The durability ratio, 1 = pristine, 0 = broken.
    pub fn ratio(&self) -> f32 {
        if self.is_damageable() {
            self.remaining() as f32 / self.max_damage as f32
        } else {
            1.0
        }
    }

    /// Whether the low-durability warning applies, by either threshold.
    pub fn needs_warning(&self, min_value: i64, min_percentage: f64) -> bool {
        if !self.is_damageable() {
            return false;
        }
        let remaining = self.remaining();
        let by_value = (remaining as i64) <= min_value;
        let by_ratio = self.ratio() <= min_percentage as f32;
        by_value || by_ratio
    }

    /// The durability text a `NUMBER` or `PERCENTAGE` display shows.
    pub fn durability_text(&self, percent: bool) -> String {
        if !self.is_damageable() {
            return String::new();
        }
        if percent {
            format!("{}%", (self.ratio() * 100.0).round() as u32)
        } else {
            self.remaining().to_string()
        }
    }
}

/// One frame's view of the local player, as the HUD needs it.
#[derive(Clone, Debug)]
pub struct EquipmentSnapshot {
    /// Head, chest, legs, feet — `None` for an empty slot.
    pub armor: [Option<StackInfo>; 4],
    pub offhand: Option<StackInfo>,
    pub main_hand: Option<StackInfo>,
    /// The selected hotbar slot, 0-8.
    pub selected: usize,
    /// The main arm is the right one (the off hand sits left of the hotbar).
    pub right_handed: bool,
    /// The attack indicator is set to the hotbar position.
    pub attack_indicator_hotbar: bool,
    /// The attack strength is still charging (< 1).
    pub attack_charging: bool,
    /// The GUI width and height in GUI pixels.
    pub screen: [f32; 2],
    /// The host's monotonic clock, in milliseconds.
    pub now_ms: u64,
}

impl EquipmentSnapshot {
    pub fn empty(screen: [f32; 2]) -> EquipmentSnapshot {
        EquipmentSnapshot {
            armor: [None, None, None, None],
            offhand: None,
            main_hand: None,
            selected: 0,
            right_handed: true,
            attack_indicator_hotbar: false,
            attack_charging: false,
            screen,
            now_ms: 0,
        }
    }

    /// The armor stacks in draw order (head first, or feet first when
    /// reversed), with the slot each came from.
    pub fn armor_order(&self, reversed: bool) -> Vec<(SlotKind, Option<&StackInfo>)> {
        let mut slots: Vec<(SlotKind, Option<&StackInfo>)> = SlotKind::ARMOR_ORDER
            .iter()
            .map(|&kind| {
                let i = armor_index(kind);
                (kind, self.armor[i].as_ref())
            })
            .collect();
        if reversed {
            slots.reverse();
        }
        slots
    }

    /// Whether at least one armor slot holds an item.
    pub fn any_armor(&self) -> bool {
        self.armor.iter().any(|s| s.is_some())
    }

    /// How many armor slots hold an item.
    pub fn armor_count(&self) -> usize {
        self.armor.iter().filter(|s| s.is_some()).count()
    }
}

/// The index of an armor slot in [`EquipmentSnapshot::armor`].
pub fn armor_index(kind: SlotKind) -> usize {
    match kind {
        SlotKind::Head => 0,
        SlotKind::Chest => 1,
        SlotKind::Legs => 2,
        SlotKind::Feet => 3,
        _ => 3,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn helmet(damage: u32, max: u32) -> StackInfo {
        StackInfo {
            item: "minecraft:iron_helmet".into(),
            count: 1,
            damage,
            max_damage: max,
            glint: false,
        }
    }

    #[test]
    fn durability_math() {
        let stack = helmet(20, 100);
        assert!(stack.is_damageable());
        assert_eq!(stack.remaining(), 80);
        assert!((stack.ratio() - 0.8).abs() < 1e-6);
        assert_eq!(stack.durability_text(false), "80");
        assert_eq!(stack.durability_text(true), "80%");
        let tool = StackInfo {
            item: "minecraft:stone".into(),
            count: 1,
            damage: 0,
            max_damage: 0,
            glint: false,
        };
        assert!(!tool.is_damageable());
        assert!(!tool.needs_warning(5, 0.05));
    }

    #[test]
    fn the_glint_flag_travels_with_the_snapshot() {
        // The layout does not branch on it; the game side does, rebuilding a
        // stack that shimmers. A round trip must not lose it.
        let mut snapshot = EquipmentSnapshot::empty([400.0, 300.0]);
        snapshot.armor[0] = Some(StackInfo {
            item: "minecraft:diamond_helmet".into(),
            count: 1,
            damage: 2,
            max_damage: 363,
            glint: true,
        });
        let carried = snapshot.armor_order(false)[0].1.cloned();
        assert_eq!(carried.map(|s| s.glint), Some(true));
        assert!(!StackInfo::empty().glint);
    }

    #[test]
    fn warnings_apply_by_value_or_percentage() {
        // 10 of 100 left: 10 <= 20 by value, 0.1 > 0.05 by percentage.
        let low = helmet(90, 100);
        assert!(low.needs_warning(20, 0.05));
        // Neither threshold is met: 10 > 5 and 0.1 > 0.05.
        assert!(!low.needs_warning(5, 0.05));
        // The percentage threshold alone triggers it.
        assert!(low.needs_warning(5, 0.15));
    }

    #[test]
    fn armor_ordering_and_counts() {
        let mut snapshot = EquipmentSnapshot::empty([400.0, 300.0]);
        snapshot.armor[0] = Some(helmet(0, 100));
        snapshot.armor[3] = Some(StackInfo {
            item: "minecraft:iron_boots".into(),
            count: 1,
            damage: 3,
            max_damage: 100,
            glint: false,
        });
        assert!(snapshot.any_armor());
        assert_eq!(snapshot.armor_count(), 2);
        let order: Vec<SlotKind> = snapshot
            .armor_order(false)
            .into_iter()
            .map(|(k, _)| k)
            .collect();
        assert_eq!(
            order,
            vec![
                SlotKind::Head,
                SlotKind::Chest,
                SlotKind::Legs,
                SlotKind::Feet
            ]
        );
        let reversed: Vec<SlotKind> = snapshot
            .armor_order(true)
            .into_iter()
            .map(|(k, _)| k)
            .collect();
        assert_eq!(
            reversed,
            vec![
                SlotKind::Feet,
                SlotKind::Legs,
                SlotKind::Chest,
                SlotKind::Head
            ]
        );
    }

    #[test]
    fn empty_icons_match_vanilla_names() {
        assert_eq!(SlotKind::Head.empty_icon(), "helmet");
        assert_eq!(SlotKind::OffHand.empty_icon(), "shield");
        assert_eq!(armor_index(SlotKind::Chest), 1);
    }
}
