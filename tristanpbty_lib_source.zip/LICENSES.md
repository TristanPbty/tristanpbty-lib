# Licenses and attributions

## This project

MIT © TristanPbty. Each crate's `Cargo.toml` carries the same grant.

## horizon-native-mod-template (MIT)

The packaging approach (`tools/package.py`: a reproducible, source-only
`.hnmod` with `horizon-native.json` + `mixins/<id>/`), the standalone
"runtime.rs is both a library and an injected module" pattern, and the
staging flow (`tools/stage.sh`) are adapted from
https://github.com/horizon-rust/horizon-native-mod-template (MIT), itself
based on levzzz5154's Veinminer packager. No game code is included.

## uku3lig/armor-hud (MIT) and BerdinskiyBear's Armor HUD

The behavior, geometry constants (slot size 22, step 20, hotbar offset 98,
off-hand 29, attack indicator 23), the configuration vocabulary
(anchors, sides, `widgetShown`, `offhandSlotBehavior`, warning thresholds)
and the off-hand/main-hand durability placement are reimplemented in Rust
from https://github.com/uku3lig/armor-hud (MIT). The original Java/Kotlin
code was read for behavior; none of it runs or ships here.

The low-durability warning mark is a pixel-for-pixel reproduction of that
mod's `warn.png` (MIT) as filled rectangles — the same red dome with white
stripes — because a source-only `.hnmod` cannot carry texture files. The
Armor Hud project's icon (`branding/tristanpbty_armor_hud.png`) is that
mod's `icon.png` (MIT), provided by the author as the emblem they wanted:
the red-and-white warning dome above a turtle in a slot with a durability
bar.

## uku3lig/ukulib (MPL-2.0)

The inspiration for a shared widget/config library beneath per-mod code.
Different language, platform and API; no code is derived from it. If code
were ever ported from it, MPL-2.0's file-level notices would be added.

## Horizon, horizon-mixins

The platform this builds on (MIT). This repository contains no Horizon
source, no Minecraft assets, no game binaries.
