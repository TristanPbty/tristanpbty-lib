//! The live side of a configuration: typed access, change notification,
//! dirty tracking and debounced saving.
//!
//! Horizon's HUD hooks run every frame, so reads must be cheap (a map lookup)
//! and writes must not touch the disk. A `ConfigRuntime` keeps the values in
//! memory, marks the store dirty on change, and saves at most once per
//! debounce window when the host calls [`ConfigRuntime::tick`] from its frame
//! hook.

use crate::config::persistence::{self, Disk, Loaded};
use crate::config::schema::{ConfigEntry, ConfigSchema, Limits};
use crate::config::validation::{check_range, coerce};
use crate::config::value::ConfigValue;
use crate::json::Json;
use std::collections::BTreeMap;
use std::path::{Path, PathBuf};
use std::time::{Duration, SystemTime, UNIX_EPOCH};

/// What a change listener hears.
#[derive(Clone, Debug)]
pub struct Change<'a> {
    pub key: &'a str,
    pub from: ConfigValue,
    pub to: ConfigValue,
}

/// A boxed change listener.
pub type Listener = Box<dyn Fn(&Change<'_>) + Send>;

/// Milliseconds since the Unix epoch, for the debounce clock.
pub fn now_ms() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as u64)
        .unwrap_or(0)
}

/// The in-memory configuration of one mod.
pub struct ConfigRuntime {
    schema: &'static ConfigSchema,
    values: BTreeMap<String, ConfigValue>,
    listeners: Vec<Listener>,
    /// True when a change has not been saved yet.
    dirty: bool,
    last_save_ms: u64,
    debounce: Duration,
    path: Option<PathBuf>,
    disk: Option<Box<dyn Disk>>,
    /// Problems from the last load, kept for the log.
    pub load_report: Vec<String>,
}

impl ConfigRuntime {
    /// A runtime over a schema, with no storage attached: values are the
    /// defaults and saving is a no-op. Unit tests use this form.
    pub fn in_memory(schema: &'static ConfigSchema) -> ConfigRuntime {
        ConfigRuntime {
            schema,
            values: persistence::default_values(schema),
            listeners: Vec::new(),
            dirty: false,
            last_save_ms: 0,
            debounce: Duration::from_millis(500),
            path: None,
            disk: None,
            load_report: Vec::new(),
        }
    }

    /// Attaches storage and loads it. When the file cannot be read at all the
    /// defaults are used and the reason is recorded (never a panic: a broken
    /// config must not stop the game).
    pub fn with_storage(
        schema: &'static ConfigSchema,
        disk: Box<dyn Disk>,
        path: PathBuf,
        migrations: &[crate::config::migration::Migration],
    ) -> ConfigRuntime {
        let mut runtime = ConfigRuntime::in_memory(schema);
        let report = match persistence::load(disk.as_ref(), &path, schema, migrations) {
            Ok(Loaded {
                values,
                problems,
                migrations,
                fresh,
            }) => {
                runtime.values = values;
                let mut report = problems.iter().map(|p| p.to_string()).collect::<Vec<_>>();
                if fresh {
                    report.push("no configuration file yet: defaults are in use".to_string());
                }
                report.extend(migrations.iter().map(|n| format!("migrated: {n}")));
                report
            }
            Err(error) => {
                // Keep the defaults; the old file is left untouched so the
                // player can repair it by hand.
                vec![format!(
                    "could not read {}: {}; using defaults",
                    error.path(),
                    error.cause()
                )]
            }
        };
        runtime.load_report = report;
        runtime.disk = Some(disk);
        runtime.path = Some(path);
        runtime
    }

    pub fn schema(&self) -> &'static ConfigSchema {
        self.schema
    }

    /// The storage path, when storage is attached.
    pub fn path(&self) -> Option<&Path> {
        self.path.as_deref()
    }

    /// Reads a value. Unknown keys return `None` (they are schema bugs, and
    /// the mod's own accessors turn them into defaults).
    pub fn get(&self, key: &str) -> Option<&ConfigValue> {
        self.values.get(key)
    }

    pub fn bool(&self, key: &str) -> bool {
        self.get(key)
            .and_then(ConfigValue::as_bool)
            .unwrap_or(false)
    }

    pub fn int(&self, key: &str) -> i64 {
        self.get(key).and_then(ConfigValue::as_i64).unwrap_or(0)
    }

    pub fn float(&self, key: &str) -> f64 {
        self.get(key).and_then(ConfigValue::as_f64).unwrap_or(0.0)
    }

    pub fn text(&self, key: &str) -> &str {
        self.get(key).and_then(ConfigValue::as_str).unwrap_or("")
    }

    pub fn color(&self, key: &str) -> u32 {
        self.get(key)
            .and_then(ConfigValue::as_color)
            .unwrap_or(0xFFFF_FFFF)
    }

    pub fn position(&self, key: &str) -> (i32, i32) {
        self.get(key)
            .and_then(ConfigValue::as_position)
            .unwrap_or((0, 0))
    }

    pub fn scale(&self, key: &str) -> f32 {
        self.get(key).and_then(ConfigValue::as_scale).unwrap_or(1.0)
    }

    /// Writes a value through the schema's validation. Out-of-range or
    /// mistyped values are clamped or refused; the return says whether the
    /// stored value changed.
    pub fn set(&mut self, key: &str, value: ConfigValue) -> bool {
        let Some(entry) = self.schema.entry(key) else {
            return false;
        };
        let value = clamp_to_entry(entry, value);
        if let Some(current) = self.values.get(key) {
            if current == &value {
                return false;
            }
            let change = Change {
                key,
                from: current.clone(),
                to: value.clone(),
            };
            self.values.insert(key.to_string(), value);
            for listener in &self.listeners {
                listener(&change);
            }
            self.dirty = true;
            true
        } else {
            false
        }
    }

    /// Subscribes to changes.
    pub fn on_change(&mut self, listener: Listener) {
        self.listeners.push(listener);
    }

    /// Restores every entry to its default, notifying the listeners of each
    /// value that changes (as [`set`](ConfigRuntime::set) does). The mod
    /// manager's reset button uses this.
    pub fn reset(&mut self) {
        let defaults = persistence::default_values(self.schema);
        let keys: Vec<String> = defaults.keys().cloned().collect();
        for key in keys {
            if let (Some(from), Some(to)) = (self.values.get(&key).cloned(), defaults.get(&key))
                && from != *to
            {
                let change = Change {
                    key: &key,
                    from,
                    to: to.clone(),
                };
                self.values.insert(key.clone(), change.to.clone());
                for listener in &self.listeners {
                    listener(&change);
                }
                self.dirty = true;
            }
        }
    }

    /// True when a change awaits saving.
    pub fn is_dirty(&self) -> bool {
        self.dirty
    }

    /// The frame tick: saves when a change has been sitting dirty for the
    /// debounce window. `now_ms` comes from the host so tests decide the
    /// clock. Returns true when a save was attempted.
    pub fn tick(&mut self, now_ms: u64) -> bool {
        if !self.dirty {
            return false;
        }
        if now_ms.saturating_sub(self.last_save_ms) < self.debounce.as_millis() as u64 {
            return false;
        }
        self.save(now_ms)
    }

    /// Saves now, whatever the debounce says.
    pub fn save(&mut self, now_ms: u64) -> bool {
        let Some(disk) = self.disk.as_ref() else {
            self.dirty = false;
            return false;
        };
        let Some(path) = self.path.clone() else {
            self.dirty = false;
            return false;
        };
        let saved = persistence::save(disk.as_ref(), &path, self.schema, &self.values).is_ok();
        self.dirty = false;
        self.last_save_ms = now_ms;
        saved
    }

    /// Parses and applies a JSON value typed into a widget field (used by
    /// the number and color inputs).
    pub fn set_from_json(&mut self, key: &str, json: &Json) -> bool {
        let Some(entry) = self.schema.entry(key) else {
            return false;
        };
        match coerce(entry, json).and_then(|v| check_range(entry, &v).map(|()| v)) {
            Ok(v) => self.set(key, v),
            Err(_) => false,
        }
    }
}

/// Clamps a typed value into the entry's limits, converting where the widget
/// model naturally produces a near type (a float slider into an int entry).
fn clamp_to_entry(entry: &ConfigEntry, value: ConfigValue) -> ConfigValue {
    match (&entry.limits, value) {
        (Limits::Int(lo, hi), ConfigValue::Int(i)) => ConfigValue::Int(i.clamp(*lo, *hi)),
        (Limits::Int(lo, hi), ConfigValue::Float(f)) => {
            ConfigValue::Int((f as i64).clamp(*lo, *hi))
        }
        (Limits::Float(lo, hi, step), ConfigValue::Float(f)) => {
            let lo = *lo;
            let hi = *hi;
            let step = *step;
            let snapped = if step > 0.0 {
                ((f - lo) / step).round() * step + lo
            } else {
                f
            };
            ConfigValue::Float(snapped.clamp(lo, hi))
        }
        (Limits::Scale(lo, hi), ConfigValue::Scale(s)) => ConfigValue::Scale(s.clamp(*lo, *hi)),
        (Limits::Scale(lo, hi), ConfigValue::Float(f)) => {
            ConfigValue::Scale((f as f32).clamp(*lo, *hi))
        }
        (_, other) => other,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::persistence::MemoryDisk;
    use crate::config::schema::{ConfigEntry, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[
        ConfigEntry::bool("enabled", "Enabled", "help", true),
        ConfigEntry::int("offsetX", "X", "help", 0, -50, 50),
        ConfigEntry::float("ratio", "Ratio", "help", 0.1, 0.0, 1.0, 0.05),
    ];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn typed_accessors_read_defaults() {
        let runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(runtime.bool("enabled"));
        assert_eq!(runtime.int("offsetX"), 0);
        assert_eq!(runtime.float("ratio"), 0.1);
        assert!(!runtime.bool("missing"));
    }

    #[test]
    fn set_validates_and_clamps() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(runtime.set("offsetX", ConfigValue::Int(999)));
        assert_eq!(runtime.int("offsetX"), 50);
        assert!(runtime.set("offsetX", ConfigValue::Float(-3.0)));
        assert_eq!(runtime.int("offsetX"), -3);
        assert!(!runtime.set("offsetX", ConfigValue::Int(-3))); // unchanged
        assert!(!runtime.set("nowhere", ConfigValue::Bool(true)));
        runtime.set("ratio", ConfigValue::Float(0.123456));
        assert_eq!(runtime.float("ratio"), 0.1); // snapped to the 0.05 step
    }

    #[test]
    fn listeners_hear_changes() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let heard = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let sink = heard.clone();
        runtime.on_change(Box::new(move |c: &Change<'_>| {
            sink.lock().unwrap().push((c.key.to_string(), c.to.clone()));
        }));
        runtime.set("enabled", ConfigValue::Bool(false));
        let heard = heard.lock().unwrap();
        assert_eq!(heard.len(), 1);
        assert_eq!(heard[0].0, "enabled");
        assert_eq!(heard[0].1, ConfigValue::Bool(false));
    }

    #[test]
    fn reset_restores_defaults_and_tells_the_listeners() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        runtime.set("enabled", ConfigValue::Bool(false));
        runtime.set("offsetX", ConfigValue::Int(12));
        let heard = std::sync::Arc::new(std::sync::Mutex::new(Vec::new()));
        let sink = heard.clone();
        runtime.on_change(Box::new(move |c: &Change<'_>| {
            sink.lock().unwrap().push((c.key.to_string(), c.to.clone()));
        }));
        runtime.reset();
        assert!(runtime.bool("enabled"));
        assert_eq!(runtime.int("offsetX"), 0);
        assert!(runtime.is_dirty());
        // Only the two changed entries were announced.
        {
            let log = heard.lock().unwrap();
            let mut keys: Vec<_> = log.iter().map(|(k, _)| k.as_str()).collect();
            keys.sort_unstable();
            assert_eq!(keys, ["enabled", "offsetX"]);
        }
        // A second reset with everything at its default says nothing.
        runtime.reset();
        assert_eq!(heard.lock().unwrap().len(), 2);
    }

    #[test]
    fn debounced_save_writes_the_disk() {
        let disk = MemoryDisk::default();
        let path = PathBuf::from("/config/test_mod.json");
        let mut runtime =
            ConfigRuntime::with_storage(&SCHEMA, Box::new(disk.clone()), path.clone(), &[]);
        assert!(!runtime.load_report.is_empty()); // fresh-file note
        runtime.set("enabled", ConfigValue::Bool(false));
        assert!(runtime.is_dirty());
        assert!(!runtime.tick(100)); // inside the debounce window
        assert!(runtime.tick(10_000)); // outside it
        assert!(!runtime.is_dirty());
        // The shared disk now holds the new value, and only that file.
        let text = disk.read(&path).expect("file was written");
        assert!(text.contains("\"enabled\": false"));
        let reloaded = ConfigRuntime::with_storage(&SCHEMA, Box::new(disk), path, &[]);
        assert!(!reloaded.bool("enabled"));
    }

    #[test]
    fn json_setting_goes_through_validation() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        assert!(runtime.set_from_json("offsetX", &Json::number("7")));
        assert_eq!(runtime.int("offsetX"), 7);
        assert!(!runtime.set_from_json("offsetX", &Json::Bool(true)));
        assert!(!runtime.set_from_json("offsetX", &Json::number("999")));
        assert_eq!(runtime.int("offsetX"), 7);
    }
}
