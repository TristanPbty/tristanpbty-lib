//! The color picker: a swatch that opens hue/saturation/value sliders plus a
//! `#RRGGBB` field, editing a color entry.

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, TEXT, Widget, draw_border, draw_label,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::ConfigValue;
use crate::utils::{Rect, argb, channels};

pub struct ColorPicker {
    key: String,
    rect: Rect,
    open: bool,
}

impl ColorPicker {
    pub fn new(key: &str, rect: Rect) -> ColorPicker {
        ColorPicker {
            key: key.to_string(),
            rect,
            open: false,
        }
    }

    fn hsv(runtime: &ConfigRuntime, key: &str) -> [f64; 3] {
        let c = runtime.color(key);
        let (r, g, b) = (
            channels(c).1 as f64 / 255.0,
            channels(c).2 as f64 / 255.0,
            channels(c).3 as f64 / 255.0,
        );
        let max = r.max(g).max(b);
        let min = r.min(g).min(b);
        let d = max - min;
        let h = if d == 0.0 {
            0.0
        } else if max == r {
            60.0 * (((g - b) / d) % 6.0)
        } else if max == g {
            60.0 * ((b - r) / d + 2.0)
        } else {
            60.0 * ((r - g) / d + 4.0)
        };
        let h = if h < 0.0 { h + 360.0 } else { h };
        [h, if max == 0.0 { 0.0 } else { d / max }, max]
    }

    fn apply_hsv(&self, runtime: &mut ConfigRuntime, hsv: [f64; 3]) -> bool {
        let [h, s, v] = hsv;
        let c = v * s;
        let x = c * (1.0 - ((h / 60.0) % 2.0 - 1.0).abs());
        let m = v - c;
        let (r, g, b) = match (h / 60.0) as u32 {
            0 => (c, x, 0.0),
            1 => (x, c, 0.0),
            2 => (0.0, c, x),
            3 => (0.0, x, c),
            4 => (x, 0.0, c),
            _ => (c, 0.0, x),
        };
        let to8 = |v: f64| (v * 255.0).round().clamp(0.0, 255.0) as u8;
        runtime.set(
            &self.key,
            ConfigValue::Color(argb(0xFF, to8(r + m), to8(g + m), to8(b + m))),
        )
    }

    fn popup_rect(&self) -> Rect {
        Rect::new(
            self.rect.x,
            self.rect.bottom() + 1.0,
            self.rect.w.max(120.0),
            3.0 * 20.0 + 2.0,
        )
    }
}

impl Widget for ColorPicker {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        let color = runtime.color(&self.key);
        // The swatch: the color on a checkered-looking panel.
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: PANEL,
        });
        draw_border(out, self.rect, if focused { ACCENT } else { super::BORDER });
        out.push(DrawCmd::Fill {
            rect: [
                self.rect.x + 2.0,
                self.rect.y + 2.0,
                self.rect.w - 4.0,
                self.rect.h - 4.0,
            ],
            argb: color | 0xFF00_0000,
        });
        let label = format!("#{:06X}", color & 0x00FF_FFFF);
        draw_label(
            out,
            &label,
            [self.rect.x, self.rect.y + self.rect.h + 2.0],
            TEXT,
        );
        if self.open {
            let popup = self.popup_rect();
            out.push(DrawCmd::Fill {
                rect: [popup.x, popup.y, popup.w, popup.h],
                argb: PANEL,
            });
            draw_border(out, popup, super::BORDER);
            let hsv = Self::hsv(runtime, &self.key);
            for (i, name) in ["hue", "sat", "val"].iter().enumerate() {
                draw_label(
                    out,
                    name,
                    [popup.x + 4.0, popup.y + 5.0 + i as f32 * 20.0],
                    super::TEXT_DIM,
                );
                let v = hsv[i];
                let bar = Rect::new(
                    popup.x + 34.0,
                    popup.y + 4.0 + i as f32 * 20.0,
                    popup.w - 40.0,
                    12.0,
                );
                // A gradient hint: the bar's fill in the channel's color.
                let channel_color = match i {
                    0 => argb(0xFF, 200, 60, 60),
                    1 => argb(0xFF, 60, 200, 60),
                    _ => argb(0xFF, 60, 60, 200),
                };
                out.push(DrawCmd::Fill {
                    rect: [bar.x, bar.y, bar.w, bar.h],
                    argb: super::TRACK,
                });
                let frac = match i {
                    0 => v / 360.0,
                    _ => v,
                };
                out.push(DrawCmd::Fill {
                    rect: [bar.x, bar.y, bar.w * frac as f32, bar.h],
                    argb: channel_color,
                });
            }
        }
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        match event {
            InputEvent::Press { pos, button: 0 } if self.rect.contains(*pos) => {
                self.open = !self.open;
                InputResult::consumed()
            }
            InputEvent::Scroll { pos, steps } if self.open && self.popup_rect().contains(*pos) => {
                // Scrolling a channel row adjusts that channel.
                let row = ((pos[1] - self.popup_rect().y) / 20.0) as usize;
                if row >= 3 {
                    return InputResult::ignored();
                }
                let mut hsv = Self::hsv(runtime, &self.key);
                let delta = -steps[1] as f64
                    * match row {
                        0 => 6.0,
                        _ => 0.02,
                    };
                hsv[row] = match row {
                    0 => (hsv[row] + delta).rem_euclid(360.0),
                    _ => (hsv[row] + delta).clamp(0.0, 1.0),
                };
                InputResult::changed_if(self.apply_hsv(runtime, hsv))
            }
            InputEvent::Press { pos, button: 0 }
                if self.open && self.popup_rect().contains(*pos) =>
            {
                // A click inside a channel row sets the channel from the
                // position along the bar.
                let popup = self.popup_rect();
                let row = ((pos[1] - popup.y) / 20.0) as usize;
                if row >= 3 {
                    return InputResult::consumed();
                }
                let bar_x = popup.x + 34.0;
                let bar_w = popup.w - 40.0;
                let frac = ((pos[0] - bar_x) / bar_w).clamp(0.0, 1.0) as f64;
                let mut hsv = Self::hsv(runtime, &self.key);
                hsv[row] = match row {
                    0 => frac * 360.0,
                    _ => frac,
                };
                InputResult::changed_if(self.apply_hsv(runtime, hsv))
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::color(
        "warningColor",
        "Warning color",
        "help",
        0x00FF_8000,
    )];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "display",
        label: "Display",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn swatch_opens_and_channels_adjust() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut picker = ColorPicker::new("warningColor", Rect::new(0.0, 0.0, 40.0, 14.0));
        // Open the popup.
        picker.input(
            &InputEvent::Press {
                pos: [20.0, 7.0],
                button: 0,
            },
            &mut runtime,
        );
        // Click along the hue bar (first row) at 50%: hue 180 = cyan.
        // The popup is 120 wide starting at the swatch; the bar runs from
        // x 34 to 114.
        let result = picker.input(
            &InputEvent::Press {
                pos: [74.0, 20.0],
                button: 0,
            },
            &mut runtime,
        );
        assert!(result.changed);
        let color = runtime.color("warningColor");
        let (_, r, g, b) = channels(color);
        assert_eq!((r, g, b), (0, 255, 255));
    }

    #[test]
    fn hsv_round_trips() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        runtime.set("warningColor", ConfigValue::Color(0x00FF_0000));
        let hsv = ColorPicker::hsv(&runtime, "warningColor");
        assert_eq!(hsv[0].round(), 0.0); // red hue
        assert_eq!(hsv[1], 1.0);
        assert_eq!(hsv[2], 1.0);
    }
}
