//! The anchor vocabulary HUD mods share: where a widget attaches to the
//! screen, on which side, and in which direction it grows.
//!
//! The names follow the vocabulary of the reference armor HUD mods so a
//! player moving between them finds the same options, while the geometry
//! rules below are written once instead of per mod.

/// Where a HUD widget is attached.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Anchor {
    /// Top of the screen, horizontally centered.
    TopCenter,
    /// Upper corner on the preferred side.
    Top,
    /// Vertically centered on the preferred side.
    Center,
    /// Bottom corner on the preferred side.
    Bottom,
    /// Beside the hotbar, above it.
    #[default]
    Hotbar,
}

impl Anchor {
    pub const ALL: [Anchor; 5] = [
        Anchor::TopCenter,
        Anchor::Top,
        Anchor::Center,
        Anchor::Bottom,
        Anchor::Hotbar,
    ];

    pub fn name(self) -> &'static str {
        match self {
            Anchor::TopCenter => "TOP_CENTER",
            Anchor::Top => "TOP",
            Anchor::Center => "CENTER",
            Anchor::Bottom => "BOTTOM",
            Anchor::Hotbar => "HOTBAR",
        }
    }

    pub fn from_name(name: &str) -> Option<Anchor> {
        Anchor::ALL.into_iter().find(|a| a.name() == name)
    }

    pub fn is_top(self) -> bool {
        matches!(self, Anchor::Top | Anchor::TopCenter)
    }
}

/// The side a widget sits on when its anchor has one.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Side {
    #[default]
    Left,
    Right,
}

impl Side {
    pub fn name(self) -> &'static str {
        match self {
            Side::Left => "LEFT",
            Side::Right => "RIGHT",
        }
    }

    pub fn from_name(name: &str) -> Option<Side> {
        match name {
            "LEFT" => Some(Side::Left),
            "RIGHT" => Some(Side::Right),
            _ => None,
        }
    }

    pub fn opposite(self) -> Side {
        match self {
            Side::Left => Side::Right,
            Side::Right => Side::Left,
        }
    }

    /// -1 for left, +1 for right: the sign that turns "distance from the
    /// anchor" into screen movement.
    pub fn sign(self) -> f32 {
        match self {
            Side::Left => -1.0,
            Side::Right => 1.0,
        }
    }
}

/// The direction a row of slots grows in.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Default)]
pub enum Orientation {
    #[default]
    Horizontal,
    Vertical,
}

impl Orientation {
    pub fn name(self) -> &'static str {
        match self {
            Orientation::Horizontal => "HORIZONTAL",
            Orientation::Vertical => "VERTICAL",
        }
    }

    pub fn from_name(name: &str) -> Option<Orientation> {
        match name {
            "HORIZONTAL" => Some(Orientation::Horizontal),
            "VERTICAL" => Some(Orientation::Vertical),
            _ => None,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn anchors_round_trip_by_name() {
        for a in Anchor::ALL {
            assert_eq!(Anchor::from_name(a.name()), Some(a));
        }
        assert_eq!(Anchor::from_name("NOWHERE"), None);
        assert!(Anchor::Top.is_top());
        assert!(Anchor::TopCenter.is_top());
        assert!(!Anchor::Hotbar.is_top());
    }

    #[test]
    fn sides_and_orientations_round_trip() {
        assert_eq!(Side::from_name(Side::Left.name()), Some(Side::Left));
        assert_eq!(Side::Left.opposite(), Side::Right);
        assert_eq!(Side::Right.sign(), 1.0);
        assert_eq!(
            Orientation::from_name(Orientation::Vertical.name()),
            Some(Orientation::Vertical)
        );
    }
}
