//! Color helpers around 32-bit ARGB, following vanilla's ARGB conventions.
//!
//! Horizon's GUI helpers take colors as `u32` in `0xAARRGGBB` order (the
//! alpha in the most significant byte); these helpers build and inspect that
//! representation and reproduce vanilla's item durability bar hue.

/// An opaque white, as the HUD sprites are tinted by default.
pub const WHITE: u32 = 0xFFFF_FFFF;

/// Builds an ARGB color from 8-bit channels.
pub const fn argb(a: u8, r: u8, g: u8, b: u8) -> u32 {
    ((a as u32) << 24) | ((r as u32) << 16) | ((g as u32) << 8) | b as u32
}

/// Builds an opaque RGB color.
pub const fn rgb(r: u8, g: u8, b: u8) -> u32 {
    argb(0xFF, r, g, b)
}

/// Returns `(a, r, g, b)` of an ARGB color.
pub const fn channels(c: u32) -> (u8, u8, u8, u8) {
    ((c >> 24) as u8, (c >> 16) as u8, (c >> 8) as u8, c as u8)
}

/// Applies `alpha` (0..=1) to an opaque color.
pub fn with_alpha(c: u32, alpha: f32) -> u32 {
    let a = (alpha.clamp(0.0, 1.0) * 255.0) as u8;
    let (_, r, g, b) = channels(c);
    argb(a, r, g, b)
}

/// Vanilla `Mth.hsvToRgb` for the saturation and value the HUD uses.
fn hsv_to_rgb(mut hue: f32, saturation: f32, value: f32) -> [u8; 3] {
    hue = (hue - hue.floor()) * 6.0;
    let f = hue - hue.floor();
    let p = value * (1.0 - saturation);
    let q = value * (1.0 - f * saturation);
    let t = value * (1.0 - (1.0 - f) * saturation);
    let (r, g, b) = match hue as i32 % 6 {
        0 => (value, t, p),
        1 => (q, value, p),
        2 => (p, value, t),
        3 => (p, q, value),
        4 => (t, p, value),
        _ => (value, p, q),
    };
    let c = |v: f32| (v * 255.0).clamp(0.0, 255.0) as u8;
    [c(r), c(g), c(b)]
}

/// The color of a durability bar at `ratio` (1 = pristine, 0 = broken),
/// reproducing vanilla `ItemStack.getBarColor`: the hue sweeps a third of the
/// circle, green when full toward red when empty.
pub fn durability_color(ratio: f32) -> u32 {
    let ratio = ratio.clamp(0.0, 1.0);
    let [r, g, b] = hsv_to_rgb(ratio / 3.0, 1.0, 1.0);
    rgb(r, g, b)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builds_and_reads_channels() {
        let c = argb(0x80, 0x11, 0x22, 0x33);
        assert_eq!(c, 0x8011_2233);
        assert_eq!(channels(c), (0x80, 0x11, 0x22, 0x33));
    }

    #[test]
    fn durability_bar_hue_matches_vanilla_endpoints() {
        // Full durability is green, empty is red, like vanilla.
        let full = durability_color(1.0);
        let empty = durability_color(0.0);
        assert_eq!(channels(full).1, 0); // r
        assert!(channels(full).2 > 200); // g
        assert!(channels(empty).1 > 200); // r
        assert_eq!(channels(empty).2, 0); // g
    }

    #[test]
    fn alpha_application() {
        let c = with_alpha(rgb(1, 2, 3), 0.5);
        assert_eq!(c >> 24, 127);
        let clamped = with_alpha(rgb(1, 2, 3), 2.0);
        assert_eq!(clamped >> 24, 255);
    }
}
