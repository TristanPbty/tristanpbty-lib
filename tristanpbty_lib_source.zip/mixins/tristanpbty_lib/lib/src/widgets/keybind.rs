//! The keybind: a button that captures the next key press as its entry's
//! value, in Horizon's `key.keyboard.*` naming.
//!
//! Rebinding persists through the game's own settings: the host writes the
//! chosen key with `native_set_setting`-style storage (the mod's key lives in
//! `horizon-mods.txt` on the Java side of the fence; here the widget only
//! produces and displays the value, and the host stores it wherever the
//! game's keybind helper expects).

use super::{
    ACCENT, DrawCmd, InputEvent, InputResult, PANEL, PANEL_HOVER, TEXT, TEXT_DIM, Widget,
    draw_border,
};
use crate::config::runtime::ConfigRuntime;
use crate::config::value::{ConfigValue, keybind_label};
use crate::utils::Rect;

pub struct Keybind {
    key: String,
    rect: Rect,
    capturing: bool,
}

impl Keybind {
    pub fn new(key: &str, rect: Rect) -> Keybind {
        Keybind {
            key: key.to_string(),
            rect,
            capturing: false,
        }
    }

    pub fn is_capturing(&self) -> bool {
        self.capturing
    }
}

impl Widget for Keybind {
    fn key(&self) -> &str {
        &self.key
    }

    fn rect(&self) -> Rect {
        self.rect
    }

    fn draw(&self, out: &mut Vec<DrawCmd>, focused: bool, runtime: &ConfigRuntime) {
        let current = runtime.text(&self.key);
        out.push(DrawCmd::Fill {
            rect: [self.rect.x, self.rect.y, self.rect.w, self.rect.h],
            argb: if self.capturing || focused {
                PANEL_HOVER
            } else {
                PANEL
            },
        });
        draw_border(
            out,
            self.rect,
            if self.capturing {
                ACCENT
            } else {
                super::BORDER
            },
        );
        let center = self.rect.center();
        let label = if self.capturing {
            "> ? <".to_string()
        } else if current.is_empty() {
            "(none)".to_string()
        } else {
            keybind_label(current)
        };
        let rgb = if self.capturing { TEXT_DIM } else { TEXT };
        out.push(DrawCmd::Text {
            text: label,
            at: [0.0, center[1] - 4.0],
            rgb,
            shadow: true,
            center_x: Some(center[0]),
        });
    }

    fn input(&mut self, event: &InputEvent<'_>, runtime: &mut ConfigRuntime) -> InputResult {
        match event {
            InputEvent::Press { pos, button } if self.rect.contains(*pos) => {
                if self.capturing {
                    // The click itself cancels the capture.
                    self.capturing = false;
                } else {
                    self.capturing = true;
                    let _ = button;
                }
                InputResult::consumed()
            }
            InputEvent::Key { name, .. } if self.capturing => {
                self.capturing = false;
                if *name == "key.keyboard.escape" {
                    // Escape cancels the capture rather than binding itself.
                    return InputResult::consumed();
                }
                InputResult::changed_if(runtime.set(
                    &self.key,
                    ConfigValue::Keybind(std::borrow::Cow::Owned(name.to_string())),
                ))
            }
            _ => InputResult::ignored(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::config::schema::{ConfigEntry, ConfigSchema, ConfigTab};

    const ENTRIES: &[ConfigEntry] = &[ConfigEntry::keybind(
        "menuKey",
        "Menu key",
        "help",
        "key.keyboard.h",
    )];
    const TABS: &[ConfigTab] = &[ConfigTab {
        id: "general",
        label: "General",
        entries: ENTRIES,
    }];
    static SCHEMA: ConfigSchema = ConfigSchema {
        mod_id: "test_mod",
        version: 1,
        tabs: TABS,
    };

    #[test]
    fn captures_the_next_key() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut bind = Keybind::new("menuKey", Rect::new(0.0, 0.0, 80.0, 18.0));
        assert!(!bind.is_capturing());
        bind.input(
            &InputEvent::Press {
                pos: [40.0, 9.0],
                button: 0,
            },
            &mut runtime,
        );
        assert!(bind.is_capturing());
        let result = bind.input(
            &InputEvent::Key {
                name: "key.keyboard.b",
                text: Some('b'),
            },
            &mut runtime,
        );
        assert!(result.changed);
        assert!(!bind.is_capturing());
        assert_eq!(runtime.text("menuKey"), "key.keyboard.b");
    }

    #[test]
    fn escape_cancels_without_binding() {
        let mut runtime = ConfigRuntime::in_memory(&SCHEMA);
        let mut bind = Keybind::new("menuKey", Rect::new(0.0, 0.0, 80.0, 18.0));
        bind.input(
            &InputEvent::Press {
                pos: [40.0, 9.0],
                button: 0,
            },
            &mut runtime,
        );
        let result = bind.input(
            &InputEvent::Key {
                name: "key.keyboard.escape",
                text: None,
            },
            &mut runtime,
        );
        assert!(result.consumed);
        assert!(!result.changed);
        assert_eq!(runtime.text("menuKey"), "key.keyboard.h");
    }
}
