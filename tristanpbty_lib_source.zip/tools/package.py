#!/usr/bin/env python3
"""Packages Tristan's Lib as a source-only `.hnmod`, the file Horizon's
registry and launcher take.

The archive holds `horizon-native.json` and `mixins/tristanpbty_lib/` (the
bundle manifest, the `lib/` crate's Cargo.toml and sources, and the licence),
with fixed dates and modes so the same sources always give the same bytes and
the same SHA-256. Horizon's `horizon_mods::index::native` reads it without
running anything; the launcher compiles it — together with the mods that use
it — on the pinned Horizon revision. Based on the MIT-licensed packager of
horizon-native-mod-template (itself from levzzz5154's Veinminer one).
"""
import hashlib
import json
import subprocess
import sys
import tomllib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
GAME = '26.3'


def sync_bundle() -> None:
    subprocess.run([sys.executable, str(ROOT / 'tools' / 'sync_bundle.py')], check=True)


def package() -> None:
    sync_bundle()
    compat = json.loads((ROOT / 'compatibility.json').read_text())
    manifests = sorted((ROOT / 'mixins').glob('*/horizon-mixin.toml'))
    if len(manifests) != 1:
        raise SystemExit('a .hnmod holds one bundle: keep one mixins/<id>/horizon-mixin.toml')
    bundle = manifests[0].parent
    mixin = tomllib.loads(manifests[0].read_text())
    mod = mixin['mod']
    if bundle.name != mod['id']:
        raise SystemExit(f"rename mixins/{bundle.name}/ to mixins/{mod['id']}/ (the registry finds it by id)")
    if not mod['id'].replace('_', '').isalnum() or not mod['id'].islower():
        raise SystemExit('the registry takes ids of lowercase letters, digits and _ only')
    if mixin.get('compatibility', {}).get('horizon_revision') != compat['horizon_revision']:
        raise SystemExit('horizon-mixin.toml and compatibility.json pin different Horizon revisions')
    if not mixin.get('crate'):
        raise SystemExit('the library bundle stages its crate: keep the [[crate]]')
    manifest = dict(schema=1, id=mod['id'], version=mod['version'], game=GAME,
                    horizon=compat['horizon_revision'], mixins=compat['horizon_mixins_revision'])
    files = {'horizon-native.json': (json.dumps(manifest, indent=2, sort_keys=True) + '\n').encode()}
    for path in sorted(bundle.rglob('*')):
        if path.is_file() and path.suffix in ('.rs', '.toml'):
            files[path.relative_to(ROOT).as_posix()] = path.read_bytes()
    # The licence travels with the sources, as Horizon's own native mods do:
    # at the project root (a standalone checkout), or one level up (the
    # monorepo development layout).
    licence = next((p for p in (ROOT / 'LICENSES.md', ROOT.parent / 'LICENSES.md') if p.is_file()), None)
    if licence is not None:
        files.setdefault(f'mixins/{mod["id"]}/LICENSES.md', licence.read_bytes())
    out = ROOT / 'target' / f"{mod['id']}-{mod['version']}.hnmod"
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in sorted(files.items()):
            info = zipfile.ZipInfo(name, (2026, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, content)
    print(json.dumps(dict(file=str(out), size=out.stat().st_size,
                          sha256=hashlib.sha256(out.read_bytes()).hexdigest()), indent=2))


if __name__ == '__main__':
    package()
