#!/usr/bin/env python3
"""Copies the library's sources into its bundle's `lib/` crate.

The .hnmod archive must be self-contained: it carries only `horizon-native.json`
and the bundle folder, so the crate rides along as the `[[crate]]` at
`mixins/tristanpbty_lib/lib`. The bundle copy must carry no `[workspace]`
table (horizon-mixins rejects one in a bundle crate), so it is stripped while
copying. Run this after editing the library, then re-run the tests and the
packager.
"""
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEST = ROOT / "mixins" / "tristanpbty_lib" / "lib"


def cargo_without_workspace() -> str:
    """The Cargo.toml without its `[workspace]` table and the comment above it.

    The standalone project is its own workspace; a bundle crate must not be
    (horizon-mixins rejects the table), so the whole trailing block goes.
    """
    lines = (ROOT / "Cargo.toml").read_text().splitlines()
    out = []
    skipping = False
    for line in lines:
        if line.strip() == "[workspace]":
            skipping = False
            continue
        if line.startswith("# Its own workspace:"):
            skipping = True
        if not skipping:
            out.append(line)
    return "\n".join(out).rstrip() + "\n"


if DEST.exists():
    shutil.rmtree(DEST)
DEST.mkdir(parents=True)
shutil.copytree(ROOT / "src", DEST / "src")
(DEST / "Cargo.toml").write_text(cargo_without_workspace())
print(f"synced {ROOT} -> {DEST}")
