//! Validation of raw JSON values against the schema.
//!
//! A value read from disk (or typed into a widget) is only accepted when its
//! type matches the entry and it sits inside the entry's limits. Everything
//! else is reported as a problem so the caller can fall back to the default
//! and tell the player what was ignored.

use crate::config::schema::{ConfigEntry, Limits};
use crate::config::value::ConfigValue;
use crate::json::Json;
use std::borrow::Cow;

/// Why a value was refused.
#[derive(Clone, Debug, PartialEq)]
pub enum Problem {
    /// The key exists in the file but not in the schema.
    UnknownKey(String),
    /// The value's JSON type cannot feed the entry.
    WrongType {
        key: String,
        expected: &'static str,
        found: String,
    },
    /// The value is out of the entry's limits.
    OutOfRange {
        key: String,
        value: String,
        limits: String,
    },
    /// The enumeration does not know the name.
    UnknownVariant {
        key: String,
        value: String,
        known: Vec<&'static str>,
    },
}

impl std::fmt::Display for Problem {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Problem::UnknownKey(k) => write!(f, "unknown key `{k}`"),
            Problem::WrongType {
                key,
                expected,
                found,
            } => write!(f, "`{key}` expects {expected}, found {found}"),
            Problem::OutOfRange { key, value, limits } => {
                write!(f, "`{key}` = {value} is outside {limits}")
            }
            Problem::UnknownVariant { key, value, known } => {
                write!(f, "`{key}` = {value} is not one of {}", known.join(", "))
            }
        }
    }
}

/// Converts a JSON value into the typed value the entry wants, or explains
/// why it cannot.
pub fn coerce(entry: &ConfigEntry, json: &Json) -> Result<ConfigValue, Problem> {
    let wrong = |expected: &'static str| Problem::WrongType {
        key: entry.id.to_string(),
        expected,
        found: json_kind(json),
    };
    match &entry.default {
        ConfigValue::Bool(_) => json
            .as_bool()
            .map(ConfigValue::Bool)
            .ok_or(wrong("a boolean")),
        ConfigValue::Int(_) => match json {
            Json::Number(n) if !n.contains('.') && !n.contains('e') && !n.contains('E') => n
                .parse::<i64>()
                .map(ConfigValue::Int)
                .map_err(|_| wrong("an integer")),
            _ => Err(wrong("an integer")),
        },
        ConfigValue::Float(_) => json
            .as_f64()
            .map(ConfigValue::Float)
            .ok_or(wrong("a number")),
        ConfigValue::Str(_) => json
            .as_str()
            .map(|s| ConfigValue::Str(Cow::Owned(s.to_string())))
            .ok_or(wrong("a string")),
        ConfigValue::Enum(_) => {
            let name = json.as_str().ok_or(wrong("a name"))?;
            match entry.limits.variants() {
                Some(known) if known.contains(&name) => {
                    Ok(ConfigValue::Enum(Cow::Owned(name.to_string())))
                }
                Some(known) => Err(Problem::UnknownVariant {
                    key: entry.id.to_string(),
                    value: name.to_string(),
                    known: known.to_vec(),
                }),
                None => Ok(ConfigValue::Enum(Cow::Owned(name.to_string()))),
            }
        }
        ConfigValue::Color(_) => {
            let text = json.as_str().ok_or(wrong("a #RRGGBB color"))?;
            crate::config::value::parse_color(text)
                .map(ConfigValue::Color)
                .ok_or_else(|| wrong("a #RRGGBB color"))
        }
        ConfigValue::Keybind(_) => json
            .as_str()
            .map(|s| ConfigValue::Keybind(Cow::Owned(s.to_string())))
            .ok_or(wrong("a key name")),
        ConfigValue::Position(_, _) => {
            let list = match json {
                Json::Array(a) if a.len() == 2 => a,
                _ => return Err(wrong("a [x, y] pair")),
            };
            let x = list[0].as_i64().ok_or_else(|| wrong("a [x, y] pair"))?;
            let y = list[1].as_i64().ok_or_else(|| wrong("a [x, y] pair"))?;
            Ok(ConfigValue::Position(x as i32, y as i32))
        }
        ConfigValue::Scale(_) => json
            .as_f64()
            .map(|f| ConfigValue::Scale(f as f32))
            .ok_or(wrong("a number")),
    }
}

/// Checks a typed value against the entry's limits.
pub fn check_range(entry: &ConfigEntry, value: &ConfigValue) -> Result<(), Problem> {
    let out = |v: String, limits: String| Problem::OutOfRange {
        key: entry.id.to_string(),
        value: v,
        limits,
    };
    match (&entry.limits, value) {
        (Limits::Int(lo, hi), ConfigValue::Int(i)) => {
            if (*lo..=*hi).contains(i) {
                Ok(())
            } else {
                Err(out(i.to_string(), format!("{lo}..={hi}")))
            }
        }
        (Limits::Float(lo, hi, _), ConfigValue::Float(f)) => {
            if (*lo..=*hi).contains(f) {
                Ok(())
            } else {
                Err(out(f.to_string(), format!("{lo}..={hi}")))
            }
        }
        (Limits::Scale(lo, hi), ConfigValue::Scale(s)) => {
            if (*lo..=*hi).contains(s) {
                Ok(())
            } else {
                Err(out(s.to_string(), format!("{lo}..={hi}")))
            }
        }
        _ => Ok(()),
    }
}

/// One-line description of a JSON value for messages.
fn json_kind(json: &Json) -> String {
    match json {
        Json::Null => "null".to_string(),
        Json::Bool(_) => "a boolean".to_string(),
        Json::Number(_) => "a number".to_string(),
        Json::String(_) => "a string".to_string(),
        Json::Array(_) => "an array".to_string(),
        Json::Object(_) => "an object".to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::json::parse;

    fn entry() -> ConfigEntry {
        ConfigEntry::int("offsetX", "X offset", "help", 0, -100, 100)
    }

    #[test]
    fn accepts_in_range_integers() {
        let e = entry();
        let json = parse("42").unwrap();
        let value = coerce(&e, &json).unwrap();
        assert_eq!(value, ConfigValue::Int(42));
        assert!(check_range(&e, &value).is_ok());
    }

    #[test]
    fn rejects_floats_for_int_entries() {
        let e = entry();
        let json = parse("4.5").unwrap();
        assert!(coerce(&e, &json).is_err());
    }

    #[test]
    fn rejects_out_of_range() {
        let e = entry();
        let value = ConfigValue::Int(1000);
        assert!(check_range(&e, &value).is_err());
    }

    #[test]
    fn enums_check_their_variants() {
        let e = ConfigEntry::enumeration("side", "Side", "help", &["LEFT", "RIGHT"], "LEFT");
        assert_eq!(
            coerce(&e, &parse("\"RIGHT\"").unwrap()).unwrap(),
            ConfigValue::Enum("RIGHT".into())
        );
        match coerce(&e, &parse("\"MIDDLE\"").unwrap()) {
            Err(Problem::UnknownVariant { .. }) => {}
            other => panic!("expected UnknownVariant, got {other:?}"),
        }
    }

    #[test]
    fn positions_parse_as_pairs() {
        let e = ConfigEntry::position("offset", "Offset", "help", 0, 0);
        let json = parse("[-3, 4]").unwrap();
        assert_eq!(coerce(&e, &json).unwrap(), ConfigValue::Position(-3, 4));
        assert!(coerce(&e, parse("[1]").as_ref().unwrap()).is_err());
    }
}
